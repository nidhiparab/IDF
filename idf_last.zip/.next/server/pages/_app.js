(() => {
var exports = {};
exports.id = 2888;
exports.ids = [2888,5405];
exports.modules = {

/***/ 6018:
/***/ ((module) => {

// Exports
module.exports = {
	"no_print": "Print_no_print__P8WdK",
	"no_shadow": "Print_no_shadow__yjvms",
	"padd1": "Print_padd1__k2J8P",
	"padd2": "Print_padd2__rp4F8",
	"padd3": "Print_padd3__fEApw",
	"padd4": "Print_padd4__Piaq4",
	"padd5": "Print_padd5__qhzQQ",
	"header": "Print_header__ooTne"
};


/***/ }),

/***/ 9225:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/idf-logo.21fd0140.png","height":71,"width":46,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAICAIAAAC+k6JsAAAAi0lEQVR42gGAAH//ABKV3QCL2gCO2wCK2gaT3QAAjNuWwOW62+uuzeoAjNsAfrTjwdjtU6XeutXslb7mAKfJ6Ym45ABg1G6r4bfT7ABVot/E2u6YwObE2u1wrOEAAJHbUqHenMPoYKbgAI/bAESh3lmp4Gyy4Gev4ESh3wAAjNtpreClzOZtruAAjdv5a0zSlOXTjAAAAABJRU5ErkJggg==","blurWidth":5,"blurHeight":8});

/***/ }),

/***/ 3777:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./styles/globals.css
var globals = __webpack_require__(6764);
// EXTERNAL MODULE: ./node_modules/bootstrap/dist/css/bootstrap.css
var bootstrap = __webpack_require__(5931);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./public/images/idf-logo.png
var idf_logo = __webpack_require__(9225);
// EXTERNAL MODULE: ./styles/Print.module.css
var Print_module = __webpack_require__(6018);
var Print_module_default = /*#__PURE__*/__webpack_require__.n(Print_module);
;// CONCATENATED MODULE: ./components/Navbar.js





// import styles from '../styles/Navbar.module.css'

const Navbar = ()=>{
    let { data: session  } = (0,react_.useSession)();
    let isAdmin = session ? session.user.isAdmin : false;
    let isHod = session ? session.user.hod.length > 0 : false;
    let isTeacher = session ? session.user.teacher.length > 0 : false;
    let isSpoc = session ? session.user.spoc.length > 0 : false;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `flex flex-col ${(Print_module_default()).no_print}`,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row justify-center",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "flex flex-col m-2",
                        href: "https://www.idf.org.in",
                        passHref: true,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "w-16 h-20 ",
                            src: idf_logo/* default */.Z,
                            alt: "idf-logo.png"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col ",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "flex flex-row m-0 font-bold",
                                children: "Indian Development Foundation"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "flex flex-row m-0 text-sm",
                                children: "A National NGO committed to Health, Education, and Development"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                className: "flex flex-row text-sm",
                                children: "IDF - Organization in Special Consultative Status with the Economic and Social Council since 2012."
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row justify-center text-white font-bold items-center font",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "nav-link bg-blue-400 hover:bg-blue-600 p-2 px-4 w-30 rounded-3xl m-2 text-center",
                        "aria-current": "page",
                        href: "/",
                        children: "Home"
                    }),
                    isAdmin ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "dropdown nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/balgurukul",
                                className: "nav-link dropbtn ",
                                children: "Balgurukul"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "dropdown-content ",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: "nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center ",
                                    href: "/balgurukul/create",
                                    "data-bs-toggle": "tooltip",
                                    "data-bs-placement": "left",
                                    title: "Create New Balgurukul",
                                    children: "Create Balgurukul"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            className: "dropdown nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                            "aria-current": "page",
                            href: "/balgurukul",
                            children: "Balgurukul"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "nav-link nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                        "aria-current": "page",
                        href: "/profile/users",
                        children: "Users"
                    }),
                    isAdmin || isHod || isTeacher || isSpoc ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "dropdown bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/profile/students",
                                className: "nav-link dropbtn",
                                children: "Students"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "dropdown-content",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    className: "nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center ",
                                    href: "/profile/student/create",
                                    "data-bs-toggle": "tooltip",
                                    "data-bs-placement": "left",
                                    title: "Create New Student",
                                    children: "Create Student"
                                })
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            className: "dropdown nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                            "aria-current": "page",
                            href: "/profile/students",
                            children: "Students"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        className: "nav-link nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                        "aria-current": "page",
                        href: "/grade",
                        children: "Grades"
                    }),
                    (()=>{
                        if (session) {
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                                        href: `/profile/user/${session.user.user_id}`,
                                        children: session.user?.f_name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                                        href: "/",
                                        onClick: ()=>{
                                            (0,react_.signOut)();
                                        },
                                        children: "SignOut"
                                    })
                                ]
                            });
                        } else {
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                                        href: "/auth/login",
                                        children: "Login"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        className: "nav-link bg-blue-400 hover:bg-blue-600 px-4 p-2 w-30 rounded-3xl m-2 text-center",
                                        href: "/auth/register",
                                        children: "Register"
                                    })
                                ]
                            });
                        }
                    })()
                ]
            })
        ]
    });
};
/* harmony default export */ const components_Navbar = (Navbar);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Footer.js
var Footer = __webpack_require__(723);
// EXTERNAL MODULE: ./components/herosection.js + 1 modules
var herosection = __webpack_require__(8190);
// EXTERNAL MODULE: ./pages/index.js + 1 modules
var pages = __webpack_require__(3270);
;// CONCATENATED MODULE: ./components/Layout.js






const Layout = ({ children  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "stylesheet",
                        href: "/../style.css"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "IDF"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Navbar, {}),
            children,
            "             "
        ]
    });
};
/* harmony default export */ const components_Layout = (Layout);

;// CONCATENATED MODULE: ./pages/_app.js





function MyApp({ Component , pageProps: { session , ...pageProps }  }) {
    return /*#__PURE__*/ jsx_runtime_.jsx(react_.SessionProvider, {
        session: session,
        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Layout, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...pageProps
            })
        })
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 5931:
/***/ (() => {



/***/ }),

/***/ 6764:
/***/ (() => {



/***/ }),

/***/ 1649:
/***/ ((module) => {

"use strict";
module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 3886:
/***/ ((module) => {

"use strict";
module.exports = require("react-slideshow-image");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,676,1664,3121,5675,3270], () => (__webpack_exec__(3777)));
module.exports = __webpack_exports__;

})();