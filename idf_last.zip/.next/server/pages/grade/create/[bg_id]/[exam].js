"use strict";
(() => {
var exports = {};
exports.id = 7301;
exports.ids = [7301];
exports.modules = {

/***/ 4443:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers_baseUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1138);
/* harmony import */ var _lib_grades__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4128);
/* harmony import */ var _styles_Grade_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6597);
/* harmony import */ var _styles_Grade_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_Grade_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2296);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(formik__WEBPACK_IMPORTED_MODULE_3__);







const CreateGrade = ({ bg , students , exam  })=>{
    const gradeOptions = bg.grade_options;
    const [selected, setSelected] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(students[0]);
    const [qualities, setQualities] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [subject, setSubject] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [intrests, setIntrests] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [specifics, setSpecifics] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const reset = ()=>{
        formik.resetForm();
        setQualities(true);
        setSubject(false);
        setIntrests(false);
        setSpecifics(false);
    };
    const formik = (0,formik__WEBPACK_IMPORTED_MODULE_3__.useFormik)({
        initialValues: {
            grades: {
                grade_qualities: {
                    Q1: "",
                    Q2: "",
                    Q3: "",
                    Q4: "",
                    Q5: "",
                    Q6: "",
                    Q7: "",
                    Q8: "",
                    Q9: "",
                    Q10: "",
                    Q11: "",
                    Q12: ""
                },
                grade_subjects: {
                    Q1: "",
                    Q2: "",
                    Q3: "",
                    Q4: "",
                    Q5: ""
                },
                grade_intrests: {
                    Q1: "",
                    Q2: "",
                    Q3: "",
                    Q4: "",
                    Q5: "",
                    Q6: "",
                    Q7: "",
                    Q8: "",
                    Q9: ""
                },
                grade_specifics: {
                    Q1: "",
                    Q2: "",
                    Q3: ""
                }
            }
        },
        validate: (values)=>{
            const errors = {
                grades: {
                    grade_qualities: {},
                    grade_subjects: {},
                    grade_intrests: {},
                    grade_specifics: {}
                }
            };
            for (const [key, value] of Object.entries(values.grades.grade_qualities)){
                if (value === "") errors.grades.grade_qualities[key] = "Required";
            }
            for (const [key1, value1] of Object.entries(values.grades.grade_subjects)){
                if (value1 === "") errors.grades.grade_subjects[key1] = "Required";
            }
            for (const [key2, value2] of Object.entries(values.grades.grade_intrests)){
                if (value2 === "") errors.grades.grade_intrests[key2] = "Required";
            }
            if (values.grades.grade_specifics.Q1 === "") {
                errors.grades.grade_specifics.Q1 = "Required";
            }
            if (values.grades.grade_specifics.Q2 === "") {
                errors.grades.grade_specifics.Q2 = "Required";
            }
            if (values.grades.grade_specifics.Q3 === "") {
                errors.grades.grade_specifics.Q3 = "Required";
            }
            return errors;
        },
        onSubmit: async (values)=>{
            let grade_qualities = [];
            let grade_subjects = [];
            let grade_intrests = [];
            let grade_specifics = [];
            for (const [key, value] of Object.entries(values.grade_qualities)){
                grade_qualities.push(value);
            }
            for (const [key1, value1] of Object.entries(values.grade_subjects)){
                grade_subjects.push(value1);
            }
            for (const [key2, value2] of Object.entries(values.grade_intrests)){
                grade_intrests.push(value2);
            }
            for (const [key3, value3] of Object.entries(values.grade_specifics)){
                grade_specifics.push(value3);
            }
            let res = await fetch(`${_helpers_baseUrl__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z}/api/student/grade/ins`, {
                method: "POST",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    student_id: selected.student_id,
                    bg_id: selected.bg_id,
                    exam: exam,
                    grade: selected.grade,
                    grades: values.grades
                })
            });
            if (res.error) {
                alert(res.error);
            } else {
                alert("Submitted");
                reset();
            }
            let data = await res.json();
        }
    });
    function changeTab(e, tab) {
        e.preventDefault();
        setQualities(tab == "qualities" ? true : false);
        setSubject(tab == "subjects" ? true : false);
        setIntrests(tab == "intrests" ? true : false);
        setSpecifics(tab == "specifics" ? true : false);
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(formik__WEBPACK_IMPORTED_MODULE_3__.FormikProvider, {
        value: formik,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-blue-600 flex justify-center text-center h-60",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                    className: "m-auto text-5xl text-white font-extrabold",
                    children: [
                        "Evaluation for ",
                        exam
                    ]
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "flex flex-row justify-content-center m-5 w-auto",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col p-20 shadow-xl shadow-slate-100 hover:shadow-slate-700 rounded-xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "font-extrabold text-blue-600 text-center justify-center",
                                children: "Student"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                children: !selected ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                className: "text-blue-700",
                                                children: [
                                                    selected.f_name,
                                                    " ",
                                                    selected.m_name,
                                                    " ",
                                                    selected.l_name
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                        className: "text-blue-600 text-2xl",
                                                        children: selected.grade
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                        className: "text-blue-600 text-2xl",
                                                        children: selected.dob
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                        className: "text-blue-600 text-2xl",
                                                        children: selected.gender
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
                        onSubmit: formik.handleSubmit,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "flex flex-col p-20 pt-10 shadow-xl shadow-slate-100 hover:shadow-slate-700 rounded-xl w-auto",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "font-extrabold text-blue-600 text-center justify-center",
                                    children: "Sections"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: "flex flex-row ",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: qualities ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "qualities");
                                            },
                                            children: "Qualities"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: subject ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "subjects");
                                            },
                                            children: "Academics"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: intrests ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "intrests");
                                            },
                                            children: "Intrests"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: specifics ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "specifics");
                                            },
                                            children: "Specifics"
                                        })
                                    ]
                                }),
                                (()=>{
                                    if (!qualities) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                    else {
                                        let obj = "grade_qualities";
                                        let gradeOptions = _lib_grades__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z[obj];
                                        let columns = gradeOptions.columns;
                                        let grade_opt = gradeOptions.options;
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                Object.keys(columns).map((key_col)=>{
                                                    let value = columns[key_col];
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                className: "text-blue-600 font-bold text-lg",
                                                                children: value
                                                            }),
                                                            formik.errors.grades?.[obj]?.[key_col] && formik.touched.grades?.[obj]?.[key_col] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "text-red-500",
                                                                children: formik.errors.grades[obj][key_col]
                                                            }) : null,
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "border-2 hover:border-blue-600 p-1",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: (_styles_Grade_module_css__WEBPACK_IMPORTED_MODULE_5___default().radio_toolbar),
                                                                    children: Object.keys(grade_opt).map((key_opt)=>{
                                                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_3__.Field, {
                                                                                    type: "radio",
                                                                                    id: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    name: `grades.${obj}.${key_col}`,
                                                                                    value: key_opt
                                                                                }, `${obj}.${key_opt}`),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                    htmlFor: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    children: [
                                                                                        grade_opt[key_opt],
                                                                                        " "
                                                                                    ]
                                                                                }, `${obj}.${key_opt}l`)
                                                                            ]
                                                                        });
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }, key_col);
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-2 mt-5 border-blue-200 w-full hover:bg-gradient-to-r from-blue-500 to-indigo-500 rounded-md py-3 hover:text-gray-50 text-lg",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setQualities(false);
                                                        setSubject(true);
                                                    },
                                                    children: "Next"
                                                })
                                            ]
                                        });
                                    }
                                })(),
                                (()=>{
                                    if (!subject) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                    else {
                                        let obj = "grade_subjects";
                                        let gradeOptions = _lib_grades__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z[obj];
                                        let columns = gradeOptions.columns;
                                        let grade_opt = gradeOptions.options;
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                            children: "Grades for Subjects "
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                            children: Object.keys(grade_opt).map((key_opt)=>{
                                                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h6", {
                                                                    children: grade_opt[key_opt]
                                                                }, grade_opt[key_opt]);
                                                            })
                                                        })
                                                    ]
                                                }),
                                                Object.keys(columns).map((key_col)=>{
                                                    let value = columns[key_col];
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                className: "text-blue-600 font-bold text-lg",
                                                                children: value
                                                            }),
                                                            formik.errors.grades?.[obj]?.[key_col] && formik.touched.grades?.[obj]?.[key_col] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "text-red-500",
                                                                children: formik.errors.grades[obj][key_col]
                                                            }) : null,
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "border-2 hover:border-blue-600 p-1",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: (_styles_Grade_module_css__WEBPACK_IMPORTED_MODULE_5___default().radio_toolbar),
                                                                    children: Object.keys(grade_opt).map((key_opt)=>{
                                                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_3__.Field, {
                                                                                    type: "radio",
                                                                                    id: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    name: `grades.${obj}.${key_col}`,
                                                                                    value: key_opt
                                                                                }, `${obj}.${key_opt}`),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                    htmlFor: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    children: [
                                                                                        grade_opt[key_opt].split(" (")[0],
                                                                                        " "
                                                                                    ]
                                                                                }, `${obj}.${key_opt}l`)
                                                                            ]
                                                                        });
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }, key_col);
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-2 mt-5 border-blue-200 w-full hover:bg-gradient-to-r from-blue-500 to-indigo-500 rounded-md py-3 hover:text-gray-50 text-lg",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setSubject(false);
                                                        setIntrests(true);
                                                    },
                                                    children: "Next"
                                                })
                                            ]
                                        });
                                    }
                                })(),
                                (()=>{
                                    if (!intrests) return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
                                    else {
                                        let obj = "grade_intrests";
                                        let gradeOptions = _lib_grades__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z[obj];
                                        let columns = gradeOptions.columns;
                                        let grade_opt = gradeOptions.options;
                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                Object.keys(columns).map((key_col)=>{
                                                    let value = columns[key_col];
                                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                                                className: "text-blue-600 font-bold text-lg",
                                                                children: value
                                                            }),
                                                            formik.errors.grades?.[obj]?.[key_col] && formik.touched.grades?.[obj]?.[key_col] ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "text-red-500",
                                                                children: formik.errors.grades[obj][key_col]
                                                            }) : null,
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                className: "border-2 hover:border-blue-600 p-1",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                                    className: (_styles_Grade_module_css__WEBPACK_IMPORTED_MODULE_5___default().radio_toolbar),
                                                                    children: Object.keys(grade_opt).map((key_opt)=>{
                                                                        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(formik__WEBPACK_IMPORTED_MODULE_3__.Field, {
                                                                                    type: "radio",
                                                                                    id: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    name: `grades.${obj}.${key_col}`,
                                                                                    value: key_opt
                                                                                }, `${obj}.${key_opt}`),
                                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("label", {
                                                                                    htmlFor: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    children: [
                                                                                        grade_opt[key_opt],
                                                                                        " "
                                                                                    ]
                                                                                }, `${obj}.${key_opt}l`)
                                                                            ]
                                                                        });
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }, key_col);
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    className: "border-2 mt-5 border-blue-200 w-full hover:bg-gradient-to-r from-blue-500 to-indigo-500 rounded-md py-3 hover:text-gray-50 text-lg",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setIntrests(false);
                                                        setSpecifics(true);
                                                    },
                                                    children: "Next"
                                                })
                                            ]
                                        });
                                    }
                                })(),
                                !specifics ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {}) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-blue-600 font-bold text-lg pt-4",
                                            htmlFor: "Q1",
                                            children: "Is there any specific or extraordinary talent / quality in the child? Please specify. "
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "bg-white focus:shadow-outline border border-gray-300 rounded-lg py-2 px-4 block w-full appearance-none leading-normal",
                                            type: "textarea",
                                            ...formik.getFieldProps("grades.grade_specifics.Q1")
                                        }),
                                        formik.errors?.grades?.grade_specifics?.Q1 && formik.touched?.grades?.grade_specifics?.Q1 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-red-500",
                                            children: formik.errors.grades.grade_specifics.Q1
                                        }) : null,
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-blue-600 font-bold text-lg pt-4",
                                            htmlFor: "grade",
                                            children: "Is there any specific or unusual challenge or problem faced by the child? Kindly explain."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "bg-white focus:shadow-outline border border-gray-300 rounded-lg py-2 px-4 block w-full appearance-none leading-normal",
                                            type: "textarea",
                                            ...formik.getFieldProps("grades.grade_specifics.Q2")
                                        }),
                                        formik.errors?.grades?.grade_specifics?.Q2 && formik.touched?.grades?.grade_specifics?.Q2 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-red-500",
                                            children: formik.errors.grades.grade_specifics.Q2
                                        }) : null,
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                            className: "text-blue-600 font-bold text-lg pt-4",
                                            htmlFor: "grade",
                                            children: "Any specific action plan or suggestion with regard to the child? Please share."
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                            className: "bg-white focus:shadow-outline border border-gray-300 rounded-lg py-2 px-4 block w-full appearance-none leading-normal",
                                            type: "textarea",
                                            ...formik.getFieldProps("grades.grade_specifics.Q3")
                                        }),
                                        formik.errors?.grades?.grade_specifics?.Q3 && formik.touched?.grades?.grade_specifics?.Q3 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: "text-red-500",
                                            children: formik.errors.grades.grade_specifics.Q3
                                        }) : null,
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "border-2 border-blue-200 w-full hover:bg-emerald-600 rounded-md py-3 hover:text-gray-50 text-lg",
                                            type: "submit",
                                            children: "Submit"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "flex flex-col p-10 w-3/12 shadow-xl shadow-slate-100 hover:shadow-slate-700 rounded-xl",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "font-extrabold text-blue-600 text-center justify-center",
                                children: "All students"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "overflow-y-auto h-30",
                                children: students?.map((student)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: "p-2 mb-2 bg-yellow-100 hover:bg-yellow-200 rounded-xl w-11/12 ",
                                        onClick: (e)=>{
                                            e.preventDefault();
                                            setSelected(student);
                                            reset();
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            className: "text-blue-700 font-semibold text-center",
                                            children: [
                                                " ",
                                                student.f_name,
                                                " ",
                                                student.m_name,
                                                " ",
                                                student.l_name
                                            ]
                                        })
                                    }, student.student_id);
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps({ params: { bg_id , exam  }  }) {
    const bg_data = await fetch(`${_helpers_baseUrl__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z}/api/balgurukul/${bg_id}`);
    const stdnt = await fetch(`${_helpers_baseUrl__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z}/api/student/bg/${bg_id}`);
    const bg = await bg_data.json();
    const stdn = await stdnt.json();
    if (stdn.length == 0) {
        return {
            redirect: {
                permanent: false,
                destination: "/balgurukul/" + bg_id
            },
            props: {}
        };
    }
    return {
        props: {
            bg,
            students: stdn,
            exam
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CreateGrade);


/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9915], () => (__webpack_exec__(4443)));
module.exports = __webpack_exports__;

})();