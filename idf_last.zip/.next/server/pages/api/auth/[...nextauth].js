"use strict";
(() => {
var exports = {};
exports.id = 3748;
exports.ids = [3748];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 2509:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _nextauth_)
});

;// CONCATENATED MODULE: external "next-auth"
const external_next_auth_namespaceObject = require("next-auth");
var external_next_auth_default = /*#__PURE__*/__webpack_require__.n(external_next_auth_namespaceObject);
// EXTERNAL MODULE: ./lib/db.js
var db = __webpack_require__(2759);
// EXTERNAL MODULE: external "bcryptjs"
var external_bcryptjs_ = __webpack_require__(8432);
;// CONCATENATED MODULE: external "next-auth/providers/credentials"
const credentials_namespaceObject = require("next-auth/providers/credentials");
var credentials_default = /*#__PURE__*/__webpack_require__.n(credentials_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/auth/[...nextauth].js




/* harmony default export */ const _nextauth_ = (external_next_auth_default()({
    // Configure one or more authentication providers
    providers: [
        credentials_default()({
            name: "credentials",
            credentials: {
                email: {
                    label: "Email",
                    type: "email",
                    placeholder: "Enter your email"
                },
                password: {
                    label: "Password",
                    type: "password"
                }
            },
            authorize: async (credentials)=>{
                let dbUser = await (0,db/* default */.Z)({
                    query: `SELECT * FROM auth where email=? LIMIT 1`,
                    values: [
                        credentials.email
                    ]
                });
                if (dbUser.length < 0) return null; // User not fount
                if (!await (0,external_bcryptjs_.compare)(credentials.password, dbUser[0].hash)) return null; // Passwords do not match
                let userData = await (0,db/* default */.Z)({
                    query: `SELECT * FROM user where user_id=? LIMIT 1`,
                    values: [
                        dbUser[0].user_id
                    ]
                });
                let isAdmin = await (0,db/* default */.Z)({
                    query: `SELECT * FROM admin where user_id=? LIMIT 1`,
                    values: [
                        dbUser[0].user_id
                    ]
                });
                if (isAdmin.length > 0) isAdmin = true;
                let hodData = await (0,db/* default */.Z)({
                    query: `SELECT bg_id FROM hod where user_id=? `,
                    values: [
                        dbUser[0].user_id
                    ]
                });
                let spocData = await (0,db/* default */.Z)({
                    query: `SELECT bg_id FROM spoc where user_id=? `,
                    values: [
                        dbUser[0].user_id
                    ]
                });
                let teacherData = await (0,db/* default */.Z)({
                    query: `SELECT bg_id FROM teacher where user_id=? `,
                    values: [
                        dbUser[0].user_id
                    ]
                });
                if (userData.length < 0) return null; // User Data not found
                let user = {
                    email: dbUser[0].email,
                    ...userData[0],
                    isAdmin,
                    hod: hodData.map((x)=>x.bg_id),
                    spoc: spocData.map((x)=>x.bg_id),
                    teacher: teacherData.map((x)=>x.bg_id)
                };
                return user;
            }
        })
    ],
    pages: {
        signIn: "/auth/login",
        error: "/auth/error"
    },
    callbacks: {
        async signIn ({}) {
            return true;
        },
        jwt: ({ token , user  })=>{
            if (user) {
                token = {
                    ...user
                };
            }
            return token;
        },
        session: ({ token , session  })=>{
            session.user = {
                ...token
            };
            return session;
        }
    },
    secret: process.env.NEXTAUTH_SECRET,
    jwt: {
        secret: process.env.NEXTAUTH_SECRET,
        encryption: true
    }
}));


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2509));
module.exports = __webpack_exports__;

})();