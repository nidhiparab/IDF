"use strict";
(() => {
var exports = {};
exports.id = 1635;
exports.ids = [1635];
exports.modules = {

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 1069:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ allUSers)
/* harmony export */ });
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2759);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);


async function allUSers(req, res) {
    if (req.method !== "POST") return res.json({
        message: "Method not allowed"
    });
    let { desgination , title , f_name , m_name , l_name , mob , qualification , user_id  } = req.body;
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.getSession)({
        req
    });
    if (!session) return res.json({
        message: "You should be logged in"
    });
    let sessionUserID = session?.user.user_id;
    if (sessionUserID !== user_id) return res.json({
        message: "You can't update other user's profile"
    });
    let user = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: `UPDATE user SET desgination=?,title=?,f_name=?,m_name=?,l_name=?,mob=?,qualification=? WHERE user_id=?`,
        values: [
            desgination,
            title,
            f_name,
            m_name,
            l_name,
            mob,
            qualification,
            user_id
        ]
    });
    res.json({
        message: user.affectedRows == 1 ? "success" : "failed"
    });
// res.json({ message: user })
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1069));
module.exports = __webpack_exports__;

})();