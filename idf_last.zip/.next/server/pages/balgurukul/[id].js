"use strict";
(() => {
var exports = {};
exports.id = 6296;
exports.ids = [6296,858];
exports.modules = {

/***/ 6968:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _id_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./components/Modals/CustomModal.js
var CustomModal = __webpack_require__(7519);
// EXTERNAL MODULE: ./helpers/baseUrl.js
var baseUrl = __webpack_require__(1138);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/Admin/balgurukul/info.js



function AdminButtons({ modal , bg_id  }) {
    return /*#__PURE__*/ _jsxs(_Fragment, {
        children: [
            /*#__PURE__*/ _jsx("button", {
                className: "delete",
                onClick: ()=>modal(true),
                children: "Delete"
            }),
            /*#__PURE__*/ _jsx(Link, {
                href: "update/[id]",
                as: `update/${bg_id}`,
                className: "btn btn-primary",
                children: "Update this page"
            })
        ]
    });
}

// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
;// CONCATENATED MODULE: ./components/Manage.js






const Manage = ({ user , users , users_list , bg_id  })=>{
    let title = user.charAt(0).toUpperCase() + user.slice(1);
    let plural = title + "s";
    const [actualUsers, setActualUsers] = (0,external_react_.useState)(users);
    users.map((user, i)=>{
        users_list = users_list.filter((user2)=>user2.user_id != user.user_id);
    });
    const [filter, setFilter] = (0,external_react_.useState)(users_list);
    const [name, setName] = (0,external_react_.useState)("");
    (0,external_react_.useEffect)(()=>{
        if (name) {
            let filtered_data = users_list.filter((user)=>{
                let fullName = user.f_name + " " + user.m_name + " " + user.l_name;
                return fullName.toLowerCase().includes(name.toLowerCase());
            });
            setFilter(filtered_data);
        } else {
            setFilter(users_list);
        }
    }, [
        name
    ]);
    async function remove(user_id) {
        const res = await fetch(`${baseUrl/* default */.Z}/api/user/role`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                role: user,
                user_id,
                bg_id,
                add: false
            })
        });
        const res2 = await res.json(); //------------------show error
        console.log(res2);
        let filUserslist = filter;
        filUserslist.push(actualUsers.find((user)=>user.user_id == user_id));
        setFilter(filUserslist);
        let filActualUsers = actualUsers.filter((user)=>user.user_id != user_id);
        setActualUsers(filActualUsers);
        if (res2.error) {
            console.log(res2.error);
        }
    }
    async function add(user_id) {
        const res = await fetch(`${baseUrl/* default */.Z}/api/user/role`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                role: user,
                user_id,
                bg_id,
                add: true
            })
        });
        const res2 = await res.json(); //------------------show error
        console.log(res2);
        let filActualUsers = actualUsers;
        filActualUsers.push(filter.find((user)=>user.user_id == user_id));
        setActualUsers(filActualUsers);
        let filUserslist = filter.filter((user)=>user.user_id != user_id);
        setFilter(filUserslist);
        if (res2.error) {
            console.log(res2.error);
        }
    }
    const [isOpen, setIsOpen] = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(CustomModal/* default */.Z, {
                show: isOpen,
                onClose: ()=>{
                    setIsOpen(false);
                },
                top: "10%",
                left: "20%",
                bottom: "10%",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "p-5 text-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "bg-blue-600 flex justify-center text-center h-20 text-white font-extrabold",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                className: "m-auto text-5xl text-white font-extrabold",
                                children: [
                                    "Manage ",
                                    title
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-row p-5",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col overflow-y-auto h-30",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                            className: "",
                                            children: plural
                                        }),
                                        actualUsers?.map((user, i)=>{
                                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                className: "flex flex-row bg-yellow-100 p-2 justify-end m-1",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                        className: "flex flex-col p-1 ml-2 text-black font-semibold text-decoration-none",
                                                        href: `/profile/user/${user.user_id}`,
                                                        children: [
                                                            user.f_name,
                                                            " ",
                                                            user.m_name,
                                                            " ",
                                                            user.l_name,
                                                            " "
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                        className: "flex flex-col bg-red-500 text-white p-1 ml-2 rounded-xl",
                                                        onClick: (e)=>{
                                                            e.preventDefault;
                                                            remove(user.user_id);
                                                        },
                                                        children: "Remove"
                                                    })
                                                ]
                                            }, i);
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-col",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                                    className: "",
                                                    children: "List of All Users"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                    className: "flex flex-row w-100 bg-white border rounded-xl p-2 justify-end m-1",
                                                    type: "text",
                                                    placeholder: "Search by Name",
                                                    value: name,
                                                    onChange: (e)=>{
                                                        setName(e.target.value);
                                                    }
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "flex flex-col overflow-y-auto h-30",
                                            children: filter?.map((user, i)=>{
                                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    className: "flex flex-row bg-yellow-100 p-2 justify-end m-1",
                                                    children: [
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                            className: "flex flex-col p-1 ml-2 text-black font-semibold text-decoration-none ",
                                                            href: `/profile/user/${user.user_id}`,
                                                            children: [
                                                                user.f_name,
                                                                " ",
                                                                user.m_name,
                                                                " ",
                                                                user.l_name,
                                                                " "
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                            className: "flex flex-col bg-green-500 text-white p-1 ml-2 rounded-xl",
                                                            onClick: (e)=>{
                                                                e.preventDefault;
                                                                add(user.user_id);
                                                            },
                                                            children: "Add"
                                                        })
                                                    ]
                                                }, i);
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "bg-slate-200 rounded-full font-bold mt-100 p-2 text-sm",
                onClick: ()=>setIsOpen(true),
                children: "Manage"
            })
        ]
    });
};
/* harmony default export */ const components_Manage = (Manage);

// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./pages/balgurukul/[id].js











const Product = ({ balgurukul , students , users_list  })=>{
    const router = (0,router_.useRouter)();
    const { data: session  } = (0,react_.useSession)();
    const [openModal, setOpenModal] = (0,external_react_.useState)(false);
    const [exam, setExam] = (0,external_react_.useState)("");
    const [openModalGrade, setOpenModalGrade] = (0,external_react_.useState)(false);
    const isHod = session?.user.hod.includes(balgurukul.bg_id);
    const isSpoc = session?.user.spoc.includes(balgurukul.bg_id);
    const isAdmin = session?.user.isAdmin;
    const isTeacher = session?.user.teacher.includes(balgurukul.bg_id);
    const bgDelete = async (bg_id)=>{
        const res = await fetch(`${baseUrl/* default */.Z}/api/balgurukul/delete`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                bg_id
            })
        });
        const res2 = await res.json();
        if (res2.error) {
            console.log(res2.error);
        } else {
            console.log("Success");
        }
    };
    // --------------individual page design begins here-----------------
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CustomModal/* default */.Z, {
                show: openModal,
                onClose: ()=>{
                    setOpenModal(false);
                },
                top: "10%",
                left: "30%",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "Do you really want to delete this Balgurukul?"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "If you want to undo this action later contact Admin"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "delete",
                        onClick: ()=>bgDelete(balgurukul.bg_id),
                        children: "Delete"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "cancel",
                        onClick: ()=>setOpenModal(false),
                        children: "Cancel"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(CustomModal/* default */.Z, {
                show: openModalGrade,
                onClose: ()=>{
                    setOpenModalGrade(false);
                },
                top: "10%",
                left: "30%",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "bg-blue-600 flex flex-col justify-center text-center h-20 text-white font-extrabold px-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                                className: "m-auto text-5xl text-white font-extrabold",
                                children: "Grade Students"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                className: "m-auto text-3xl text-white font-extrabold",
                                children: "Examination"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "p-5 text-center pt-2",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "px-5 pt-5",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                    type: "text",
                                    className: "bg-white border-2 h-10 w-100 text-2xl text-center font-bold",
                                    placeholder: "Exam",
                                    id: "exam",
                                    value: exam,
                                    onChange: (e)=>setExam(e.target.value)
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "grid grid-cols-2 p-5 pb-1",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn btn-primary m-2 text-2xl",
                                        disabled: exam == "",
                                        onClick: ()=>{
                                            exam == "" ? alert("Exam cannot be empty") : router.push(`/grade/create/${balgurukul.bg_id}/${exam}`);
                                        },
                                        children: "Proceed"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "btn btn-primary m-2 text-2xl",
                                        onClick: ()=>setOpenModalGrade(false),
                                        children: "Cancel"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-blue-600 flex justify-center text-center h-60",
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "m-auto text-5xl text-white font-extrabold",
                    children: balgurukul.bg_name
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mb-40 flex justify-center flex-row mx-40",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "ml-auto mt-2 pt-12 pr-12 w-auto justify-start flex flex-col h-auto",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mx-auto w-full h-auto mt-1 mb-5 p-6 bg-gradient-to-r from-blue-500 to-indigo-500 shadow-xl shadow-slate-700 rounded-xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "m-auto py-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: " text-xl text-white font-semibold roun",
                                            children: "HOD"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex flex-col m-auto",
                                        children: balgurukul.hod_users?.map((user, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                href: `/profile/user/${user.user_id}`,
                                                className: " pl-7 py-3/2 text-xl text-white font-semibold",
                                                children: [
                                                    user.title,
                                                    " ",
                                                    user.f_name,
                                                    " ",
                                                    user.l_name
                                                ]
                                            }, i))
                                    }),
                                    isAdmin ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "m-auto py-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Manage, {
                                            user: "hod",
                                            users: balgurukul.hod_users,
                                            users_list: users_list,
                                            bg_id: balgurukul.bg_id
                                        })
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mx-auto w-full h-auto mt-1 mb-5 p-6 bg-gradient-to-r from-blue-500 to-indigo-500 shadow-xl shadow-slate-700 rounded-xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "m-auto py-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: " text-xl text-white font-semibold roun",
                                            children: "SPOC"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex flex-col m-auto",
                                        children: balgurukul.spoc_users?.map((user, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                href: `/profile/user/${user.user_id}`,
                                                className: " pl-7 py-1 text-xl text-white font-semibold",
                                                children: [
                                                    user.title,
                                                    " ",
                                                    user.f_name,
                                                    " ",
                                                    user.l_name
                                                ]
                                            }, i))
                                    }),
                                    isAdmin || isHod ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "m-auto py-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Manage, {
                                            user: "spoc",
                                            users: balgurukul.spoc_users,
                                            users_list: users_list,
                                            bg_id: balgurukul.bg_id
                                        })
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "mx-auto w-full h-auto mt-1 mb-5 p-6 bg-gradient-to-r from-blue-500 to-indigo-500 shadow-xl shadow-slate-700 rounded-xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "m-auto py-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: " text-xl text-white font-semibold roun",
                                            children: "Teachers"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "flex flex-col m-auto",
                                        children: balgurukul.teacher_users?.map((user, i)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((link_default()), {
                                                href: `/profile/user/${user.user_id}`,
                                                className: "pl-7 py-3/2 text-xl text-white font-semibold",
                                                children: [
                                                    user.title,
                                                    " ",
                                                    user.f_name,
                                                    " ",
                                                    user.l_name
                                                ]
                                            }, i))
                                    }),
                                    isAdmin || isHod ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "m-auto py-2",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(components_Manage, {
                                            user: "teacher",
                                            users: balgurukul.teacher_users,
                                            users_list: users_list,
                                            bg_id: balgurukul.bg_id
                                        })
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "mr-auto w-auto pt-12 pl-12 flex flex-col justify-center items-start text-slate-900 text-xl",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Partnering Organization"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.partnering_org
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Address"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.address
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.district
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.state
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.pincode
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Management"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.org_under_bg == "nan" ? /*#__PURE__*/ jsx_runtime_.jsx("span", {}) : balgurukul.org_under_bg
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.phone == "nan" ? /*#__PURE__*/ jsx_runtime_.jsx("span", {}) : balgurukul.phone
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: balgurukul.mail == "nan" ? /*#__PURE__*/ jsx_runtime_.jsx("span", {}) : "Email: " + balgurukul.mail
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: " my-auto p-2 mr-auto w-auto pt-12 pl-12 flex flex-col justify-center items-start text-slate-900 text-xl",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                        className: "text-xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Students"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                                        className: "table-auto",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("thead", {
                                                className: "text-lg",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                    className: "bg-gray-300 text-gray-700",
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "px-4 py-2",
                                                            children: "Student Name"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "px-4 py-2",
                                                            children: "Class"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "px-4 py-2",
                                                            children: "Date Of Birth"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                                            className: "px-4 py-2",
                                                            children: "Gender"
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("tbody", {
                                                children: students?.map((std)=>{
                                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                                                        className: "bg-white text-gray-700",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                className: "border px-4 py-2",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                                    href: `/profile/student/${std.student_id}`,
                                                                    children: `${std.f_name} ${std.m_name} ${std.l_name}`
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                className: "border px-4 py-2",
                                                                children: std.grade
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                className: "border px-4 py-2",
                                                                children: std.dob
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                                                className: "border px-4 py-2",
                                                                children: std.gender
                                                            })
                                                        ]
                                                    }, std.student_id);
                                                })
                                            })
                                        ]
                                    })
                                ]
                            }),
                            isAdmin ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "delete m-2",
                                onClick: ()=>setOpenModal(true),
                                children: "Delete"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
                            isAdmin || isHod || isTeacher ? /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                className: "btn btn-primary m-2",
                                onClick: ()=>setOpenModalGrade(true),
                                children: "Grade"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}),
                            isAdmin || isHod ? /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: `update/${balgurukul.bg_id}`,
                                as: `update/${balgurukul.bg_id}`,
                                className: "btn btn-primary m-2",
                                children: "Update this Balgurukul"
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
                        ]
                    })
                ]
            })
        ]
    });
};
//--------------------------get all the data from api of that bgk------------------
async function getServerSideProps({ params: { id  }  }) {
    const res = await fetch(`${baseUrl/* default */.Z}/api/balgurukul/${id}`);
    const stdnt = await fetch(`${baseUrl/* default */.Z}/api/student/bg/${id}`);
    const users_list = await fetch(`${baseUrl/* default */.Z}/api/user/users`);
    const data = await res.json();
    const stdn = await stdnt.json();
    return {
        props: {
            balgurukul: data,
            students: stdn,
            users_list: await users_list.json()
        }
    };
}
/* harmony default export */ const _id_ = (Product);


/***/ }),

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 3918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 9931:
/***/ ((module) => {

module.exports = require("react-modal");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,676,1664,3121,5675,1088], () => (__webpack_exec__(6968)));
module.exports = __webpack_exports__;

})();