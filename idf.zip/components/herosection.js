import React from "react";
import Slideshow from "./Slideshow";

function herosection() {
  return (
    <div>
      <Slideshow />
    </div>
  );
}

export default herosection;