"use strict";
exports.id = 4585;
exports.ids = [4585];
exports.modules = {

/***/ 4585:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers_baseUrl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1138);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_Modals_CustomModal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7519);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_4__);







const StudentProfile = ({ student , grades  })=>{
    // Student Object
    //   student_id
    //   bg_id
    //   bg_name
    //   f_name
    //   m_name
    //   l_name
    //   dob
    //   gender
    //   grade
    const { data: session , status  } = (0,next_auth_react__WEBPACK_IMPORTED_MODULE_4__.useSession)();
    const isHod = session?.user.hod.includes(student.bg_id);
    const [update, setUpdate] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [f_name, setF_name] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.f_name);
    const [m_name, setM_name] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.m_name);
    const [l_name, setL_name] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.l_name);
    const [dob, setDob] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.dob);
    const [grade, setGrade] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.grade);
    const [gender, setGender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.gender);
    const [Formf_name, setFormF_name] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.f_name);
    const [Formm_name, setFormM_name] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.m_name);
    const [Forml_name, setFormL_name] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.l_name);
    const [Formdob, setFormDob] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.dob);
    const [Formgrade, setFormGrade] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.grade);
    const [Formgender, setFormGender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.gender);
    const [bg_name, setBg_name] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student?.bg_name);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleUpdateSubmit = async (event)=>{
        event.preventDefault();
        // Prepare data to send to server
        const data = {
            student_id: student.student_id,
            f_name: Formf_name,
            m_name: Formm_name,
            l_name: Forml_name,
            dob: Formdob,
            gender: Formgender,
            grade: Formgrade
        };
        // Use fetch to make a POST request to server endpoint
        const response = await fetch("/api/student/update", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(data)
        });
        let res = await response.json();
        if (res.error) return setError(res.error);
        else {
            alert("Updated Successfully");
            setUpdate(false);
            setF_name(Formf_name);
            setM_name(Formm_name);
            setL_name(Forml_name);
            setGrade(Formgrade);
            setGender(Formgender);
            setDob(Formdob);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_Modals_CustomModal__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                show: update,
                onClose: ()=>setUpdate(false),
                left: "15%",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "fixed justify-center w-2/3 bg-white shadow-lg",
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "p-6 ",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                    className: "text-3xl font-extrabold text-blue-600 mb-3",
                                    children: "Update Details"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                                    onSubmit: handleUpdateSubmit,
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: "flex flex-wrap ",
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2 pr-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "text-xl font-bold text-blue-600 mb-2",
                                                            children: "First Name"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "border border-black-600 w-full p-2 bg-white",
                                                            type: "text",
                                                            value: Formf_name,
                                                            onChange: (e)=>setFormF_name(e.target.value)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2 pl-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "text-xl font-bold text-blue-600 mb-2",
                                                            children: "Middle Name"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "border border-black-600 w-full p-2 bg-white",
                                                            type: "text",
                                                            value: Formm_name,
                                                            onChange: (e)=>setFormM_name(e.target.value)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2 pr-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "text-xl font-bold text-blue-600 mb-2",
                                                            children: "Last Name"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "border border-black-600 w-full p-2 bg-white",
                                                            type: "text",
                                                            value: Forml_name,
                                                            onChange: (e)=>setFormL_name(e.target.value)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2 pr-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "text-xl font-bold text-blue-600 mb-2",
                                                            children: "DOB"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "border border-black-600 w-full p-2 bg-white",
                                                            type: "date",
                                                            value: Formdob,
                                                            onChange: (e)=>setFormDob(e.target.value)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2 pr-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "text-xl font-bold text-blue-600 mb-2",
                                                            children: "Gender"
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                                            className: "border border-black-600 w-full p-2 bg-white",
                                                            value: Formgender,
                                                            onChange: (e)=>setFormGender(e.target.value),
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                    value: "Male",
                                                                    children: "Male"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                    value: "Female",
                                                                    children: "Female"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                                    value: "Other",
                                                                    children: "Other"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                                    className: "w-1/2 pr-4 mt-4",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                                            className: "text-xl font-bold text-blue-600 mb-2",
                                                            children: "Class"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                                            className: "border border-black-600 w-full p-2 bg-white",
                                                            type: "text",
                                                            value: Formgrade,
                                                            onChange: (e)=>setFormGrade(e.target.value)
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                            className: "bg-blue-500 text-white p-2 w-full hover:bg-blue-700",
                                            type: "submit",
                                            children: "Submit"
                                        }),
                                        error ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                            children: error
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                                    ]
                                })
                            ]
                        }),
                        "    "
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "bg-blue-600 flex justify-center text-center h-60",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                    className: "m-auto text-5xl text-white font-extrabold",
                    children: "Student Profile Page"
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "m-20 p-20 items-center shadow-2xl shadow-slate-700 rounded-2xl",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: " text-2xl",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "justify-between p-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-3xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Name"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                        className: "mt-auto mb-2",
                                        children: [
                                            f_name,
                                            " ",
                                            m_name,
                                            " ",
                                            l_name
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-3xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Date Of Birth"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: dob
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-3xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Class"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: grade
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                        className: "text-3xl font-bold text-blue-600 mt-auto mb-3",
                                        children: "Gender"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        className: "mt-auto mb-2",
                                        children: gender
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        children: isHod || session?.user?.isAdmin ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "mt-auto mb-2 text-2xl font-bold text-blue-600 border-2 border-blue-600 rounded-lg py-2 px-4 hover:bg-blue-600 hover:text-white",
                            onClick: ()=>{
                                setUpdate(true);
                                setFormF_name(f_name);
                                setFormM_name(m_name);
                                setFormL_name(l_name);
                                setFormDob(dob);
                                setFormGrade(grade);
                                setFormGender(gender);
                            },
                            children: "Update Profile"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "text-3xl font-bold text-blue-600 mt-auto mb-3",
                                children: "Results"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                                className: "table-auto w-5/6 mx-auto",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                            className: "bg-blue-600 text-gray-100",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "px-4 py-2",
                                                    children: "Grade Id"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "px-4 py-2",
                                                    children: "Balgurukul Id"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "px-4 py-2",
                                                    children: "Exam"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                                    className: "px-4 py-2",
                                                    children: "Class"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                        children: grades?.map((grade)=>{
                                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                                className: "bg-white text-gray-700 ",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border px-4 py-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: `/grade/${grade.grade_id}`,
                                                            children: grade.grade_id
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border px-4 py-2",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                            href: `/balgurukul/${grade.bg_id}`,
                                                            children: grade.bg_name
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border px-4 py-2",
                                                        children: grade.exam
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                        className: "border px-4 py-2",
                                                        children: grade.grade
                                                    }),
                                                    console.log(grade)
                                                ]
                                            }, grade.grade_id);
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps({ params: { student_id  }  }) {
    const res = await fetch(`${_helpers_baseUrl__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z}/api/student/${student_id}`);
    const data = await res.json();
    return {
        props: {
            student: data.student,
            grades: data.grades.result
        }
    };
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StudentProfile);


/***/ })

};
;