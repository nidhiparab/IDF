exports.id = 3270;
exports.ids = [3270];
exports.modules = {

/***/ 723:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6290);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_icons_fa__WEBPACK_IMPORTED_MODULE_3__);



// import styles from "../../idf/styles/Footer.module.css"




const Footer = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {});
// return (
//   <>
//     <div className={styles.footer}>
//       {/*------------- Social media icons----- */}
//       {/* <ul>
//                   <p className="text-gray-800 font-bold text-3xl pb-6">
//                       Stream<span className="text-blue-600">line</span>
//                   </p>
//                   <div className="flex gap-6 pb-5">
//                       <FaInstagram className="text-2xl cursor-pointer hover:text-yellow-600" />
//                       <FaTwitter className="text-2xl cursor-pointer hover:text-blue-600" />
//                       <FaLinkedin className="text-2xl cursor-pointer hover:text-blue-600" />
//                       <FaYoutube className="text-2xl cursor-pointer hover:text-red-600" />
//                   </div>
//               </ul> */}
//       <div className={ styles.bottom }>
//         <div className={styles.footer_col}>
//           <h4>IDF Head Office</h4>
//           <span className={ styles.off_address }>
//             L 10 / 3 & 4 Jal Ratan Deep, Bangur Nagar, Goregaon (West), Mumbai
//             400104. Maharashtra, India.
//           </span>
//           <span className={ styles.off_address }>
//             <br />
//             <b>Email:</b>
//             <Link href="info@idf.org.in"> info@idf.org.in</Link>
//           </span>
//           <span className={ styles.off_address }>
//             <b>Phone:</b>
//             <Link href="tel:+919819131388"> +919819131388</Link>
//           </span>
//           <span className={ styles.off_address }>
//             <b>Registered Charity: </b>F-10540
//           </span>
//         </div>
//         <div className={styles.footer_col}>
//           <h4 className={styles.title}>Subscribe to our Newsletter</h4>
//           <input
//           className={styles.subs_input}
//             type="text"
//             placeholder="Enter your email here"
//             name="subs"
//           ></input>
//           <br></br>
//           <button className={styles.subs}>Subscribe</button>
//         </div>
//         <div className={styles.footer_col}>
//           <h4>Quick Links</h4>
//           <Link href="/">About Us</Link>
//           <Link href="/">Projects</Link>
//           <Link href="/">Support Us</Link>
//           <Link href="/">Events</Link>
//         </div>
//       </div>
//     </div>
//     <div className={styles.end}>
//       <p>
//         © 2022 Indian Development Foundation. All rights reserved.
//         <br></br>Terms of Use | Privacy Policy
//       </p>
//     </div>
//   </>
// );
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Footer);


/***/ }),

/***/ 8190:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

"use strict";

// UNUSED EXPORTS: default

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "react-slideshow-image"
var external_react_slideshow_image_ = __webpack_require__(3886);
// EXTERNAL MODULE: ./node_modules/react-slideshow-image/dist/styles.css
var styles = __webpack_require__(5383);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/Slideshow.js


//These are Third party packages for smooth slideshow



const Slideshow_Slideshow = ()=>{
    //Array of Images
    const images = [
        "/images/Image1.png",
        "/images/Image2.png",
        "/images/Image3.png",
        "/images/Image1.png",
        "/images/Image2.png"
    ];
    //These are custom properties for zoom effect while slide-show
    const zoomInProperties = {
        indicators: true,
        scale: 1.2,
        duration: 5000,
        transitionDuration: 500,
        infinite: true,
        prevArrow: /*#__PURE__*/ _jsx("div", {
            style: {
                width: "30px",
                marginRight: "-30px",
                cursor: "pointer"
            },
            children: /*#__PURE__*/ _jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 512 512",
                fill: "#2e2e2e",
                children: /*#__PURE__*/ _jsx("path", {
                    d: "M242 180.6v-138L0 256l242 213.4V331.2h270V180.6z"
                })
            })
        }),
        nextArrow: /*#__PURE__*/ _jsx("div", {
            style: {
                width: "30px",
                marginLeft: "-30px",
                cursor: "pointer"
            },
            children: /*#__PURE__*/ _jsx("svg", {
                xmlns: "http://www.w3.org/2000/svg",
                viewBox: "0 0 512 512",
                fill: "#2e2e2e",
                children: /*#__PURE__*/ _jsx("path", {
                    d: "M512 256L270 42.6v138.2H0v150.6h270v138z"
                })
            })
        })
    };
    return /*#__PURE__*/ _jsxs("div", {
        className: "m-10",
        children: [
            /*#__PURE__*/ _jsx("h1", {
                className: "text-center text-6xl font-bold pb-10 ",
                children: /*#__PURE__*/ _jsx("span", {
                    className: "text-indigo-600"
                })
            }),
            /*#__PURE__*/ _jsx(Zoom, {
                ...zoomInProperties,
                children: images.map((each, index)=>/*#__PURE__*/ _jsx("div", {
                        className: "flex justify-center w-full h-full",
                        children: /*#__PURE__*/ _jsx(Image, {
                            src: each,
                            alt: "Some image",
                            className: "w-3/4 object-cover rounded-lg shadow-xl",
                            fill: true
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const components_Slideshow = ((/* unused pure expression or super */ null && (Slideshow_Slideshow)));

;// CONCATENATED MODULE: ./components/herosection.js



function herosection() {
    return /*#__PURE__*/ _jsx("div", {
        children: /*#__PURE__*/ _jsx(Slideshow, {})
    });
}
/* harmony default export */ const components_herosection = ((/* unused pure expression or super */ null && (herosection)));


/***/ }),

/***/ 3270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next-auth/react"
var react_ = __webpack_require__(1649);
// EXTERNAL MODULE: ./components/herosection.js + 1 modules
var herosection = __webpack_require__(8190);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
;// CONCATENATED MODULE: ./components/gallery.js



const Gallery = ()=>{
    const [selectedImage, setSelectedImage] = (0,external_react_.useState)(null);
    const images = [
        {
            id: 1,
            src: "../images/Image1.png",
            alt: "Image 1",
            title: "Image 1 Title"
        },
        {
            id: 2,
            src: "../images/Image2.png",
            alt: "Image 2",
            title: "Image 2 Title"
        },
        {
            id: 3,
            src: "../images/Image3.png",
            alt: "Image 3",
            title: "Image 3 Title"
        },
        {
            id: 1,
            src: "../images/Image1.png",
            alt: "Image 1",
            title: "Image 1 Title"
        },
        {
            id: 2,
            src: "../images/Image2.png",
            alt: "Image 2",
            title: "Image 2 Title"
        },
        {
            id: 3,
            src: "../images/Image3.png",
            alt: "Image 3",
            title: "Image 3 Title"
        },
        {
            id: 1,
            src: "../images/Image1.png",
            alt: "Image 1",
            title: "Image 1 Title"
        },
        {
            id: 2,
            src: "../images/Image2.png",
            alt: "Image 2",
            title: "Image 2 Title"
        },
        {
            id: 3,
            src: "../images/Image3.png",
            alt: "Image 3",
            title: "Image 3 Title"
        }
    ];
    const handleClick = (id)=>{
        setSelectedImage(id);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "container mx-auto px-4",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                className: "text-3xl font-medium text-center text-gray-900 mb-8",
                children: "Gallery"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "grid grid-cols-3 gap-4",
                children: images.map((image)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: image.src,
                            alt: image.alt,
                            className: "w-full rounded-lg cursor-pointer",
                            onClick: ()=>handleClick(image.id)
                        })
                    }, image.id))
            }),
            selectedImage && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "fixed inset-0 z-50 flex items-center justify-center",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-full max-w-lg bg-blue-100 rounded-lg p-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: images.find((img)=>img.id === selectedImage).src,
                            alt: "",
                            className: "w-full rounded-lg mb-4"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                            className: "text-xl font-medium text-center text-gray-900 mb-4",
                            children: images.find((img)=>img.id === selectedImage).title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            className: "bg-gray-300 hover:bg-gray-400 text-gray-800 font-medium py-2 px-4 rounded-lg",
                            onClick: ()=>setSelectedImage(null),
                            children: "Close"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const gallery = (Gallery);

// EXTERNAL MODULE: ./components/Footer.js
var Footer = __webpack_require__(723);
;// CONCATENATED MODULE: ./pages/index.js







function Home() {
    const { data: session , status  } = (0,react_.useSession)();
    // if (session) console.log(session);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " container mx-auto px-4",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: " mt-10 text-6xl font-extrabold text-center text-gray-900 mb-8 drop-shadow-lg",
                        children: "IDF Bal Gurukul"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "w-1/2 mr-8 border-solid border-2 border-white",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: "https://static.wixstatic.com/media/094b60_1776d86f0e9e4214affa5644fc4aabc5~mv2.png/v1/fill/w_866,h_655,al_c,q_90,usm_0.66_1.00_0.01,enc_auto/Bal%20Gurukul%20.png",
                                    alt: "About us",
                                    className: "w-full rounded"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: " w-1/2",
                                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-gray-700 mb-4 text-xl text-justify",
                                    children: "IDF Bal Gurukul Education is of prime importance. IDF Bal Gurukul projects are a success proven sustainable development model.  IDF in its diversified objectives has included village development and education programmes into its fold. development. From a humble beginning in tribal area in Maharashtra and also in Langadiyawas village in Rajasthan, IDF now has 300 plus Bal Gurukuls covering the length and breadth of our country. Before of April 2021 we had 300 plus Bal Gurukuls and by the March 2022 we have .currently 300 plus Bal Gurukuls. Primary donors are Blackstone Charitable Foundation supported 150 Bal Gurukuls and RBL bank Ltd. RBL bank sanctioned 130 Bal Gurukuls in this financial year. The rest are operational by virtue of individual donations."
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mt-10 items-center mb-10",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(gallery, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
}


/***/ }),

/***/ 5383:
/***/ (() => {



/***/ })

};
;