"use strict";
exports.id = 1088;
exports.ids = [1088];
exports.modules = {

/***/ 7519:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ CustomModal)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9931);
/* harmony import */ var react_modal__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_modal__WEBPACK_IMPORTED_MODULE_2__);



function CustomModal({ show , children , onClose , top , left , right , bottom  }) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_modal__WEBPACK_IMPORTED_MODULE_2___default()), {
        isOpen: show,
        onRequestClose: onClose,
        contentLabel: "Example Modal",
        ariaHideApp: false,
        style: {
            overlay: {
                position: "fixed",
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                backgroundColor: "rgba(255, 255, 255, 0.7)"
            },
            content: {
                // position: 'absolute',
                // // top,
                // // left,
                // // top: '50 %',
                // // left: '50 %',
                // // transform: 'translate(-50 %, -50 %)',
                // left: 0,
                // right: 0,
                // 'margin-left': 'auto',
                // 'margin-right': 'auto',
                // // right,
                // // width: 'max-content',
                // bottom,
                // border: '2px solid #E0E0E0',
                // background: '#fff',
                // overflow: 'auto',
                // WebkitOverflowScrolling: 'touch',
                // // borderRadius: '4px',
                // outline: 'none',
                // padding: '20px'
                position: "absolute",
                top: top,
                left: left,
                right: right,
                bottom: bottom,
                border: "2px solid #E0E0E0",
                background: "#fff",
                overflow: "auto",
                WebkitOverflowScrolling: "touch",
                // borderRadius: '4px',
                outline: "none",
                padding: "20px"
            }
        },
        children: children
    });
}


/***/ }),

/***/ 1138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// https://idf-prod.vercel.app/
const baseUrl =  true ? "https://idfbalgurukul.com" : 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseUrl);


/***/ })

};
;