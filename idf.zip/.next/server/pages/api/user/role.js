"use strict";
(() => {
var exports = {};
exports.id = 3216;
exports.ids = [3216];
exports.modules = {

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        // port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD //cekas@123
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 9958:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ Test)
/* harmony export */ });
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2759);


async function Test(req, res) {
    if (req.method !== "POST") {
        res.json({
            message: "This is POST API"
        });
        return;
    }
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_0__.getSession)({
        req
    });
    if (!session) {
        res.redirect("/auth/login");
        return;
    }
    const { role , bg_id , user_id , add  } = req.body;
    if (role === "hod" && !session.user.isAdmin) {
        res.json({
            message: "You don't have Permission of this action"
        });
        return;
    }
    if (!session.user.hod?.includes(bg_id) && !session.user.isAdmin) {
        res.json({
            message: "You don't have Permission of this action"
        });
        return;
    }
    if (add) {
        // check if bg_id and user_id already exists in role table
        let alreadyExsist = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
            query: "SELECT * FROM `" + role + "` WHERE `bg_id`=? AND `user_id`=?;",
            values: [
                bg_id,
                parseInt(user_id)
            ]
        });
        if (alreadyExsist.length > 0) {
            res.json({
                message: "User already has the role in that BG"
            });
            return;
        }
        let insert = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
            query: "INSERT INTO `" + role + "` (`bg_id`, `user_id`) VALUES (?, ?);",
            values: [
                bg_id,
                parseInt(user_id)
            ]
        });
    } else {
        //delete
        let deleteRole = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
            query: "DELETE FROM `" + role + "`WHERE `bg_id`=? AND `user_id`=?;",
            values: [
                bg_id,
                parseInt(user_id)
            ]
        });
    }
    res.json({
        message: "success"
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(9958));
module.exports = __webpack_exports__;

})();