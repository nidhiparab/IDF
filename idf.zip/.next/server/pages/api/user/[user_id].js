"use strict";
(() => {
var exports = {};
exports.id = 6060;
exports.ids = [6060];
exports.modules = {

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 3524:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ byUserId)
/* harmony export */ });
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2759);

async function byUserId(req, res) {
    const { user_id  } = req.query;
    let user = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: `SELECT user.*, auth.email FROM user JOIN auth ON user.user_id = auth.user_id WHERE user.user_id = ?;`,
        values: [
            user_id
        ]
    });
    if (user.length == 1) {
        user = user[0];
    } else {
        res.json({
            error: "User not found"
        });
    }
    let hod = [];
    let spoc = [];
    let teacher = [];
    let hodData = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: `SELECT bg_id FROM hod where user_id=? `,
        values: [
            user.user_id
        ]
    });
    for(let i = 0; i < hodData.length; i++){
        let bg_id = hodData[i].bg_id;
        let hodBg = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: `SELECT bg_name FROM bg where bg_id=? `,
            values: [
                bg_id
            ]
        });
        if (hodBg.length == 1) {
            hod.push({
                bg_id,
                bg_name: hodBg[0].bg_name
            });
        }
    }
    let spocData = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: `SELECT bg_id FROM spoc where user_id=? `,
        values: [
            user.user_id
        ]
    });
    for(let i1 = 0; i1 < spocData.length; i1++){
        let bg_id1 = spocData[i1].bg_id;
        let spocBg = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: `SELECT bg_name FROM bg where bg_id=? `,
            values: [
                bg_id1
            ]
        });
        if (spocBg.length == 1) {
            spoc.push({
                bg_id: bg_id1,
                bg_name: spocBg[0].bg_name
            });
        }
    }
    let teacherData = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: `SELECT bg_id FROM teacher where user_id=? `,
        values: [
            user.user_id
        ]
    });
    for(let i2 = 0; i2 < teacherData.length; i2++){
        let bg_id2 = teacherData[i2].bg_id;
        let teacherBg = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: `SELECT bg_name FROM bg where bg_id=? `,
            values: [
                bg_id2
            ]
        });
        if (teacherBg.length == 1) {
            teacher.push({
                bg_id: bg_id2,
                bg_name: teacherBg[0].bg_name
            });
        }
    }
    res.json({
        user,
        hod,
        spoc,
        teacher
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(3524));
module.exports = __webpack_exports__;

})();