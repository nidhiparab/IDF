"use strict";
(() => {
var exports = {};
exports.id = 5310;
exports.ids = [5310];
exports.modules = {

/***/ 8432:
/***/ ((module) => {

module.exports = require("bcryptjs");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 6603:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ registerUser)
/* harmony export */ });
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2759);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8432);
/* harmony import */ var bcryptjs__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(bcryptjs__WEBPACK_IMPORTED_MODULE_1__);


//------------API for adding new bg to database
async function registerUser(req, res) {
    if (req.method != "POST") {
        res.json({
            "message": "This is a POST API"
        }).status(404);
    }
    const { email , password , designation , title , f_name , m_name , l_name , mob , qualification  } = req.body;
    let count = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: "SELECT COUNT(*) FROM `auth`;",
        values: []
    });
    const user_id = parseInt(count[0]["COUNT(*)"]) + 1;
    // check email
    let duplicateEmail = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: "SELECT * FROM auth where `email`=?;",
        values: [
            email
        ]
    });
    if (duplicateEmail.length > 0) {
        res.status(401).json({
            error: "User with this Email Id already exists"
        });
        return;
    }
    let insertDataAuth, insertDataUser;
    // await hash(password, 10)
    insertDataAuth = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: "INSERT INTO `auth`(`user_id`, `email`, `hash`) VALUES (?,?,?);",
        values: [
            user_id,
            email,
            password
        ]
    });
    if (insertDataAuth.error) {
        res.status(402).json({
            error: insertDataAuth.error.sqlMessage
        });
        return;
    }
    if (insertDataAuth.affectedRows == 1) {
        insertDataUser = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: "INSERT INTO `user`(`user_id`, `desgination`, `title`, `f_name`, `m_name`, `l_name`, `mob`, `qualification`) VALUES (?,?,?,?,?,?,?,?);",
            values: [
                user_id,
                designation,
                title,
                f_name,
                m_name,
                l_name,
                mob,
                qualification
            ]
        });
        if (insertDataUser.error) {
            res.status(402).json({
                error: insertDataUser.error.sqlMessage
            });
            return;
        }
    }
    res.status(200).json({
        error: "None"
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6603));
module.exports = __webpack_exports__;

})();