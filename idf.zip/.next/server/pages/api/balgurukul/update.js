"use strict";
(() => {
var exports = {};
exports.id = 3533;
exports.ids = [3533];
exports.modules = {

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 2619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addBG)
/* harmony export */ });
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2759);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);


//------------API for adding new bg to database
async function addBG(req, res) {
    if (req.method != "POST") {
        res.json({
            "message": "This is a POST API"
        }).status(404);
    }
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.getSession)({
        req
    });
    if (!session) return res.status(401).redirect("/auth/login");
    if (!session?.user.isAdmin && session?.user.hod?.includes(bg_id)) return res.status(401).json({
        message: "Unauthorized"
    });
    const { bg_id , bg_name , partnering_org , address , state , state_short , district , region , pincode , org_under_bg , phone , mail , soft_delete  } = req.body;
    let updateData = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: "UPDATE `bg` SET `bg_name`=?,`partnering_org`=?,`address`=?,`district`=?,`state`=?,`state_short`=?,`region`=?,`pincode`=?,`org_under_bg`=?,`phone`=?,`mail`=?,`soft_delete`=? WHERE `bg_id`=?",
        values: [
            bg_name,
            partnering_org,
            address,
            district,
            state,
            state_short,
            region,
            pincode,
            org_under_bg,
            phone,
            mail,
            soft_delete,
            bg_id
        ]
    });
    res.json(updateData);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2619));
module.exports = __webpack_exports__;

})();