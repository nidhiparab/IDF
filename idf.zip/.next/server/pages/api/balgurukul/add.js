"use strict";
(() => {
var exports = {};
exports.id = 6158;
exports.ids = [6158];
exports.modules = {

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        // port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD //cekas@123
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 2687:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ addBG)
/* harmony export */ });
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2759);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_1__);


//------------API for adding new bg to database
async function addBG(req, res) {
    if (req.method != "POST") {
        res.json({
            "message": "This is a POST API"
        }).status(404);
    }
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_1__.getSession)({
        req
    });
    if (!session) return res.status(401).redirect("/auth/login");
    if (!session?.user.isAdmin) return res.status(401).json({
        message: "Unauthorized"
    });
    const { bg_name , partnering_org , address , state , district , region , pincode , org_under_bg , phone , mail  } = req.body;
    let soft_delete = 0;
    let stateData = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        // query: `SELECT * FROM 'bg_count' WHERE 'abbr'='${state}'`,
        query: "SELECT * FROM bg_count WHERE `abbr`= ? ",
        values: [
            state
        ]
    });
    stateData = stateData[0];
    let stateFull = stateData.state;
    let newCount = parseInt(stateData.count) + 1;
    let id = (1000 + newCount + "").slice(1);
    id = state + id;
    let updateCount = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: "UPDATE `bg_count` SET `count`= `count` + 1 WHERE `abbr`=? ;",
        values: [
            state
        ]
    });
    let insertData = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: "INSERT INTO `bg`(`bg_id`, `bg_name`, `partnering_org`, `address`, `district`, `state`, `state_short`, `region`, `pincode`, `org_under_bg`, `phone`, `mail`, `soft_delete`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);",
        values: [
            id,
            bg_name,
            partnering_org,
            address,
            district,
            stateFull,
            state,
            region,
            pincode,
            org_under_bg,
            phone,
            mail,
            soft_delete
        ]
    });
    res.json(updateCount, insertData);
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(2687));
module.exports = __webpack_exports__;

})();