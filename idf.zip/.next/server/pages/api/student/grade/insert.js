"use strict";
(() => {
var exports = {};
exports.id = 2632;
exports.ids = [2632];
exports.modules = {

/***/ 1649:
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2759:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ executeQuery)
/* harmony export */ });
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2261);
/* harmony import */ var serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(serverless_mysql__WEBPACK_IMPORTED_MODULE_0__);

const db = serverless_mysql__WEBPACK_IMPORTED_MODULE_0___default()({
    config: {
        host: process.env.MYSQL_HOST,
        // port: process.env.MYSQL_PORT,
        database: process.env.MYSQL_DATABASE,
        user: process.env.MYSQL_USER,
        password: process.env.MYSQL_PASSWORD //cekas@123
    }
});
async function executeQuery({ query , values  }) {
    try {
        const results = await db.query(query, values);
        await db.end();
        return results;
    } catch (error) {
        return {
            error
        };
    }
}


/***/ }),

/***/ 7362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ createStudent)
/* harmony export */ });
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1649);
/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2759);


async function createStudent(req, res) {
    if (req.method !== "POST") return res.status(405).json({
        message: "Method not allowed"
    });
    let { student_id , bg_id , exam , grade , grade_qualities , grade_subjects , grade_intrests , grade_specifics  } = req.body;
    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_0__.getSession)({
        req
    });
    if (!session) return res.status(401).redirect("/auth/login");
    if (!session?.user.isAdmin && (session?.user.hod?.includes(bg_id) || session?.user.teacher?.includes(bg_id))) return res.status(401).json({
        message: "Unauthorized"
    });
    let timestamp = `${new Date().getFullYear()}/${new Date().getMonth() + 1}/${new Date().getDate()}`;
    let exists = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        query: "SELECT * FROM `grade` WHERE `student_id` = ? AND `bg_id` = ? AND `exam` = ? AND `grade` = ?;",
        values: [
            student_id,
            bg_id,
            exam,
            grade
        ]
    });
    if (exists.length > 0) return res.status(500).json({
        message: "Grade already exists",
        error: exists
    });
    let count = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        query: "SELECT COUNT(*) FROM `grade`;",
        values: []
    });
    const grade_id = parseInt(count[0]["COUNT(*)"]) + 1;
    let gradeInsert = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        query: "INSERT INTO `grade`(`grade_id`, `student_id`, `bg_id`, `exam`, `grade`, `timestamp`) VALUES (?,?,?,?,?,?);",
        values: [
            grade_id,
            student_id,
            bg_id,
            exam,
            grade,
            timestamp
        ]
    });
    if (gradeInsert.affectedRows != 1) return res.status(500).json({
        message: "Error adding grade",
        error: gradeInsert
    });
    let qualitiesInsert = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        query: "INSERT INTO `grade_qualities`(`grade_id`, `Q1`, `Q2`, `Q3`, `Q4`, `Q5`, `Q6`, `Q7`, `Q8`, `Q9`, `Q10`, `Q11`, `Q12`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?);",
        values: [
            grade_id,
            ...grade_qualities
        ]
    });
    let subjectsInsert = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        query: "INSERT INTO `grade_subjects`(`grade_id`, `Q1`, `Q2`, `Q3`, `Q4`, `Q5`) VALUES (?,?,?,?,?,?);",
        values: [
            grade_id,
            ...grade_subjects
        ]
    });
    let intrestsInsert = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        query: "INSERT INTO `grade_intrests`(`grade_id`, `Q1`, `Q2`, `Q3`, `Q4`, `Q5`, `Q6`, `Q7`, `Q8`, `Q9`) VALUES (?,?,?,?,?,?,?,?,?,?);",
        values: [
            grade_id,
            ...grade_intrests
        ]
    });
    let specificsInsert = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z)({
        query: "INSERT INTO `grade_specifics`(`grade_id`, `Q1`, `Q2`, `Q3`) VALUES (?,?,?,?);",
        values: [
            grade_id,
            ...grade_specifics
        ]
    });
    res.json({
        message: specificsInsert.affectedRows == 1 ? "Student graded successfully" : "Error grading student"
    });
} // Delete Query:
 // DELETE FROM `grade` WHERE grade_id = '2';
 // DELETE FROM `grade_intrests` WHERE grade_id = '2';
 // DELETE FROM `grade_qualities` WHERE grade_id = '2';
 // DELETE FROM `grade_specifics` WHERE grade_id = '2';
 // DELETE FROM `grade_subjects` WHERE grade_id = '2';


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(7362));
module.exports = __webpack_exports__;

})();