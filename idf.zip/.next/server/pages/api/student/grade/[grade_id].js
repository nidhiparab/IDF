"use strict";
(() => {
var exports = {};
exports.id = 2616;
exports.ids = [2616];
exports.modules = {

/***/ 2261:
/***/ ((module) => {

module.exports = require("serverless-mysql");

/***/ }),

/***/ 2392:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ getGradeById)
/* harmony export */ });
/* harmony import */ var _lib_db__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2759);
/* harmony import */ var _lib_grades__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6658);


async function getGradeById(req, res) {
    let finalResult = [];
    let { grade_id  } = req.query;
    let grades = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
        query: "SELECT student.*, bg.bg_name, grade.*, DATE_FORMAT(`timestamp`, '%d-%m-%Y') as timestamp FROM `grade` JOIN `bg` ON grade.bg_id = bg.bg_id JOIN `student` ON grade.student_id = student.student_id WHERE grade.grade_id = ?;",
        values: [
            grade_id
        ]
    });
    for (const grade of grades){
        let result = {
            grade_qualities: {},
            grade_subjects: {},
            grade_intrests: {},
            grade_specifics: {}
        };
        result = {
            ...grade,
            ...result
        };
        let grade_id1 = grade.grade_id;
        let grade_qualities = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: "SELECT * FROM `grade_qualities` WHERE `grade_id` = ?;",
            values: [
                grade_id1
            ]
        });
        grade_qualities = grade_qualities[0];
        delete grade_qualities.grade_id;
        for(const key in grade_qualities){
            if (Object.hasOwnProperty.call(grade_qualities, key)) {
                const value = grade_qualities[key];
                result.grade_qualities[_lib_grades__WEBPACK_IMPORTED_MODULE_1__/* ["default"].grade_qualities.columns */ .Z.grade_qualities.columns[key]] = _lib_grades__WEBPACK_IMPORTED_MODULE_1__/* ["default"].grade_qualities.options */ .Z.grade_qualities.options[value];
            }
        }
        let grade_subjects = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: "SELECT * FROM `grade_subjects` WHERE `grade_id` = ?;",
            values: [
                grade_id1
            ]
        });
        grade_subjects = grade_subjects[0];
        delete grade_subjects.grade_id;
        for(const key1 in grade_subjects){
            if (Object.hasOwnProperty.call(grade_subjects, key1)) {
                const value1 = grade_subjects[key1];
                result.grade_subjects[_lib_grades__WEBPACK_IMPORTED_MODULE_1__/* ["default"].grade_subjects.columns */ .Z.grade_subjects.columns[key1]] = _lib_grades__WEBPACK_IMPORTED_MODULE_1__/* ["default"].grade_subjects.options */ .Z.grade_subjects.options[value1];
            }
        }
        let grade_intrests = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: "SELECT * FROM `grade_intrests` WHERE `grade_id` = ?;",
            values: [
                grade_id1
            ]
        });
        grade_intrests = grade_intrests[0];
        delete grade_intrests.grade_id;
        for(const key2 in grade_intrests){
            if (Object.hasOwnProperty.call(grade_intrests, key2)) {
                const value2 = grade_intrests[key2];
                result.grade_intrests[_lib_grades__WEBPACK_IMPORTED_MODULE_1__/* ["default"].grade_intrests.columns */ .Z.grade_intrests.columns[key2]] = _lib_grades__WEBPACK_IMPORTED_MODULE_1__/* ["default"].grade_intrests.options */ .Z.grade_intrests.options[value2];
            }
        }
        let grade_specifics = await (0,_lib_db__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)({
            query: "SELECT * FROM `grade_specifics` WHERE `grade_id` = ?;",
            values: [
                grade_id1
            ]
        });
        grade_specifics = grade_specifics[0];
        delete grade_specifics.grade_id;
        for(const key3 in grade_specifics){
            if (Object.hasOwnProperty.call(grade_specifics, key3)) {
                const value3 = grade_specifics[key3];
                result.grade_specifics[_lib_grades__WEBPACK_IMPORTED_MODULE_1__/* ["default"].grade_specifics.columns */ .Z.grade_specifics.columns[key3]] = value3;
            }
        }
        finalResult.push(result);
    }
    res.json({
        result: finalResult
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [435], () => (__webpack_exec__(2392)));
module.exports = __webpack_exports__;

})();