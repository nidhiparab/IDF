(() => {
var exports = {};
exports.id = 4987;
exports.ids = [4987];
exports.modules = {

/***/ 5920:
/***/ ((module) => {

// Exports
module.exports = {
	"filter_name": "GradeTable_filter_name__ASB_C",
	"Rbtn": "GradeTable_Rbtn__Jtt9d",
	"calendar": "GradeTable_calendar__5GSOQ"
};


/***/ }),

/***/ 1138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// https://idf-prod.vercel.app/
const baseUrl =  true ? "https://idfbalgurukul.com" : 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseUrl);


/***/ }),

/***/ 6730:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _helpers_baseUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1138);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_GradeTable_module_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5920);
/* harmony import */ var _styles_GradeTable_module_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_styles_GradeTable_module_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);







const Index = ({ query: { bg_id , student_id , grade , exam , dateLesser , dateGreater  }  })=>{
    const [bg_id_val, setBg_id] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(bg_id ? bg_id : null);
    const [student_id_val, setStudent_id] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(student_id ? student_id : null);
    const [grade_val, setGrade] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(grade ? grade : null);
    const [exam_val, setExam] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(exam ? exam : null);
    const [dateLesser_val, setDateLesser] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dateLesser ? dateLesser : null);
    const [dateGreater_val, setDateGreater] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(dateGreater ? dateGreater : null);
    let router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const [grades, setGrades] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        let getData = async ()=>{
            next_router__WEBPACK_IMPORTED_MODULE_3___default().push(`/grade?bg_id=${bg_id_val}&student_id=${student_id_val}&grade=${grade_val}&exam=${exam_val}&dateLesser=${dateLesser_val}&dateGreater=${dateGreater_val}`);
            const res = await fetch(`${_helpers_baseUrl__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z}/api/student/grade/get`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    bg_id: bg_id_val,
                    student_id: student_id_val,
                    grade: grade_val,
                    exam: exam_val,
                    dateLesser: dateLesser_val,
                    dateGreater: dateGreater_val,
                    min: true
                })
            });
            const data = await res.json();
            setGrades(data.result);
        };
        getData();
        return;
    }, [
        bg_id_val,
        dateGreater_val,
        dateLesser_val,
        exam_val,
        grade_val,
        student_id_val
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "p-4 flex space-x-4",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "w-full px-3 py-2 border rounded bg-white placeholder-gray-500 text-black",
                        type: "text",
                        placeholder: "Student Id",
                        value: student_id_val == null || student_id_val == "null" ? "" : student_id_val,
                        onChange: (e)=>setStudent_id(e.target.value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "w-full px-3 py-2 border rounded bg-white placeholder-gray-500 text-black",
                        type: "text",
                        placeholder: "Balgurukul Id",
                        value: bg_id_val == null || bg_id_val == "null" ? "" : bg_id_val,
                        onChange: (e)=>setBg_id(e.target.value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "w-full px-3 py-2 border rounded bg-white placeholder-gray-500 text-black",
                        type: "text",
                        placeholder: "Exam",
                        value: exam_val == null || exam_val == "null" ? "" : exam_val,
                        onChange: (e)=>setExam(e.target.value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: "w-full px-3 py-2 border rounded bg-white placeholder-gray-500 text-black",
                        type: "text",
                        placeholder: "Class",
                        value: grade_val == null || grade_val == "null" ? "" : grade_val,
                        onChange: (e)=>setGrade(e.target.value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: (_styles_GradeTable_module_css__WEBPACK_IMPORTED_MODULE_5___default().calendar),
                        type: "date",
                        value: dateGreater_val == null || dateGreater_val == "null" ? "" : dateGreater_val,
                        onChange: (e)=>setDateGreater(e.target.value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        className: (_styles_GradeTable_module_css__WEBPACK_IMPORTED_MODULE_5___default().calendar),
                        type: "date",
                        value: dateLesser_val == null || dateLesser_val == "null" ? "" : dateLesser_val,
                        onChange: (e)=>setDateLesser(e.target.value)
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                        className: "bg-blue-400 hover:bg-blue-600 rounded-3xl p-1 px-1 font-bold w-full text-white",
                        name: "Reset",
                        onClick: ()=>{
                            setStudent_id(null);
                            setBg_id(null);
                            setExam(null);
                            setGrade(null);
                            setDateGreater(null);
                            setDateLesser(null);
                        },
                        children: "Reset Filters"
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: " my-auto w-auto flex flex-col items-start justify-between p-2",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "text-3xl font-bold text-blue-600 px-10 mt-auto mb-3",
                        children: "Results"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("table", {
                        className: "table-auto w-5/6 mx-auto",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("thead", {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                    className: "bg-blue-600 text-gray-100",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            className: "px-4 py-2 w-1",
                                            children: "Balgurukul Id"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            className: "px-4 py-2 ",
                                            children: "Grade"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            className: "px-4 py-2",
                                            children: "Student Id"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            className: "px-4 py-2",
                                            children: "Exam"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            className: "px-4 py-2",
                                            children: "Class"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("th", {
                                            className: "px-4 py-2",
                                            children: "Date"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("tbody", {
                                children: grades?.map((grade)=>{
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("tr", {
                                        className: "bg-white text-gray-700 ",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "border px-4 py-2 font-bold ",
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `/balgurukul/${grade.bg_id}`,
                                                    className: "text-decoration-none",
                                                    children: grade.bg_name
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "border px-4 py-2 font-bold ",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `/grade/${grade.grade_id}`,
                                                    className: "text-decoration-none",
                                                    children: [
                                                        grade.f_name,
                                                        " ",
                                                        grade.m_name,
                                                        " ",
                                                        grade.l_name,
                                                        " - ",
                                                        grade.exam
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "border px-4 py-2 font-bold",
                                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                    href: `/profile/student/${grade.student_id}`,
                                                    className: "text-decoration-none",
                                                    children: [
                                                        grade.f_name,
                                                        " ",
                                                        grade.m_name,
                                                        " ",
                                                        grade.l_name
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "border px-4 py-2",
                                                children: grade.exam
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "border px-4 py-2",
                                                children: grade.grade
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("td", {
                                                className: "border px-4 py-2",
                                                children: grade.timestamp
                                            })
                                        ]
                                    }, grade.grade_id);
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
Index.getInitialProps = async ({ query  })=>{
    return {
        query
    };
};
// export async function getServerSideProps({ params: { student_id } }) {
//   const res = await fetch(`${baseUrl}/api/student/${student_id}`)
//   const data = await res.json()
//   console.log(data.grades.result);
//   return {
//     props: {
//       grades: data.grades.result
//     },
//   }
// }
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);


/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9210,676,1664], () => (__webpack_exec__(6730)));
module.exports = __webpack_exports__;

})();