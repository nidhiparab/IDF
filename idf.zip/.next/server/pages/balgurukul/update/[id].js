(() => {
var exports = {};
exports.id = 9749;
exports.ids = [9749];
exports.modules = {

/***/ 6859:
/***/ ((module) => {

// Exports
module.exports = {

};


/***/ }),

/***/ 1138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// https://idf-prod.vercel.app/
const baseUrl =  true ? "https://idf-prod.vercel.app/" : 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseUrl);


/***/ }),

/***/ 8365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styles_Create_module_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6859);
/* harmony import */ var _styles_Create_module_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_Create_module_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _helpers_baseUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1138);






const Update = ({ balgurukul  })=>{
    //---------------------------all required fields------------------
    const [bg_name, setName] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.bg_name);
    const [partnering_org, setPartner] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.partnering_org);
    const [district, setDist] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.district);
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.state);
    const [address, setAddr] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.address);
    const [region, setRegion] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.region);
    const [pincode, setPin] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.pincode);
    const [org_under_bg, setOu] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.org_under_bg);
    const [mob, setMob] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.phone.split("/")[0]);
    const [tel, setTel] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.phone.split("/")[1]);
    const [phone, setPh] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [mail, setMail] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(balgurukul.mail);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_2__.useRouter)();
    const handleSubmit = async (e)=>{
        //----------------set phone number mobile + telephone
        setPh(mob + "/" + tel);
        e.preventDefault();
        let bg_id = balgurukul.bg_id;
        let soft_delete = balgurukul.soft_delete;
        let state_short = balgurukul.state_short;
        const res = await fetch(`${_helpers_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z}/api/balgurukul/update`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                bg_id,
                bg_name,
                partnering_org,
                address,
                state,
                state_short,
                district,
                region,
                pincode,
                org_under_bg,
                phone,
                mail,
                soft_delete
            })
        });
        const res2 = await res.json() //------------------show error
        ;
        if (res2.error) {
            console.log(res2.error);
        } else {
            router.push(`/balgurukul/${bg_id}`);
            console.log("Success");
        }
    };
    // console.log(bg_name, partnering_org, state, district, region, pincode, org_under_bg, phone, mail);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: " mx-auto p-20 items-center shadow-2xl shadow-slate-700 rounded-2xl w-2/3",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
            action: "#",
            onSubmit: (e)=>handleSubmit(e),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    className: "font-bold",
                    children: "Details"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " flex space-x-4 items-center block text-sm font-medium mb-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "bg_name",
                            placeholder: "Balgurukul Name",
                            value: bg_name,
                            onChange: (e)=>{
                                setName(e.target.value);
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "partnering_org",
                            placeholder: "Partnering Organization",
                            value: partnering_org,
                            onChange: (e)=>{
                                setPartner(e.target.value);
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    className: "font-bold",
                    children: "Address"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " flex space-x-4 items-center block text-sm font-medium mb-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "address",
                            placeholder: "Address",
                            value: address,
                            onChange: (e)=>{
                                setAddr(e.target.value);
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "district",
                            placeholder: "District",
                            value: district,
                            onChange: (e)=>{
                                setDist(e.target.value);
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_styles_Create_module_css__WEBPACK_IMPORTED_MODULE_4___default().field_select),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                        className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                        id: "state",
                        name: "state",
                        value: state,
                        onChange: (e)=>{
                            setState(e.target.value);
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                className: "val",
                                value: "",
                                children: "State"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "AN",
                                children: "Andaman and Nicobar Islands"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "AP",
                                children: "Andhra Pradesh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "AR",
                                children: "Arunachal Pradesh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "AS",
                                children: "Assam"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "BR",
                                children: "Bihar"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "CH",
                                children: "Chandigarh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "CT",
                                children: "Chhattisgarh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "DN",
                                children: "Dadra and Nagar Haveli"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "DD",
                                children: "Daman and Diu"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "DL",
                                children: "Delhi"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "GA",
                                children: "Goa"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "GJ",
                                children: "Gujarat"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "HR",
                                children: "Haryana"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "HP",
                                children: "Himachal Pradesh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "JK",
                                children: "Jammu and Kashmir"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "JH",
                                children: "Jharkhand"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "KA",
                                children: "Karnataka"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "KL",
                                children: "Kerala"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "LA",
                                children: "Ladakh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "LD",
                                children: "Lakshadweep"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "MP",
                                children: "Madhya Pradesh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "MH",
                                children: "Maharashtra"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "MN",
                                children: "Manipur"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "ML",
                                children: "Meghalaya"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "MZ",
                                children: "Mizoram"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "NL",
                                children: "Nagaland"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "OR",
                                children: "Odisha"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "PY",
                                children: "Puducherry"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "PB",
                                children: "Punjab"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "RJ",
                                children: "Rajasthan"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "SK",
                                children: "Sikkim"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "TN",
                                children: "Tamil Nadu"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "TA",
                                children: "Telangana"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "TR",
                                children: "Tripura"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "UP",
                                children: "Uttar Pradesh"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "UT",
                                children: "Uttarakhand"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                value: "WB",
                                children: "West Bengal"
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " flex space-x-4 items-center block text-sm font-medium mb-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "region",
                            placeholder: "Region",
                            value: region,
                            onChange: (e)=>{
                                setRegion("SR");
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "pincode",
                            placeholder: "Pin Code",
                            value: pincode,
                            onChange: (e)=>{
                                setPin(e.target.value);
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                    className: "font-bold",
                    children: "Incharge"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " flex space-x-4 items-center block text-sm font-medium mb-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "org_under_bg",
                            placeholder: "Organization",
                            value: org_under_bg,
                            onChange: (e)=>{
                                setOu(e.target.value);
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "mail",
                            placeholder: "Email",
                            value: mail,
                            onChange: (e)=>{
                                setMail(e.target.value);
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: " flex space-x-4 items-center block text-sm font-medium mb-2",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "mob",
                            placeholder: "Mobile No.",
                            value: mob,
                            onChange: (e)=>{
                                setMob(e.target.value);
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                            className: "inline-block w-full py-3 px-4 my-2 border rounded-xl bg-slate-200 focus:outline-none border-none ",
                            type: "text",
                            name: "tel",
                            placeholder: "Telephone No.",
                            value: tel,
                            onChange: (e)=>{
                                setTel(e.target.value);
                            }
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    type: "submit",
                    className: "items-center w-full bg-indigo-500 text-white py-2 px-4 my-2 rounded-md hover:bg-indigo-600",
                    children: "Submit"
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Update);
async function getServerSideProps({ params: { id  }  }) {
    const res = await fetch(`${_helpers_baseUrl__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z}/api/balgurukul/${id}`);
    const data = await res.json();
    return {
        props: {
            balgurukul: data
        }
    };
}


/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(8365));
module.exports = __webpack_exports__;

})();