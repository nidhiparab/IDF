(() => {
var exports = {};
exports.id = 7301;
exports.ids = [7301];
exports.modules = {

/***/ 6597:
/***/ ((module) => {

// Exports
module.exports = {
	"radio_toolbar": "Grade_radio_toolbar__tsex_"
};


/***/ }),

/***/ 1138:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
// https://idf-prod.vercel.app/
const baseUrl =  true ? "https://idfbalgurukul.com" : 0;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseUrl);


/***/ }),

/***/ 5214:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _exam_),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./helpers/baseUrl.js
var baseUrl = __webpack_require__(1138);
;// CONCATENATED MODULE: ./lib/grades.js
const gradeConstants = {
    grade_qualities: {
        title: "Student's Qualities and Abilitiesumns",
        columns: {
            Q1: "Cleanliness & General Neatness",
            Q2: "Discipline",
            Q3: "Reading",
            Q4: "Writing",
            Q5: "Memory",
            Q6: "Attendance",
            Q7: "Attentiveness",
            Q8: "Nourishment",
            Q9: "Physical Fitness",
            Q10: "Honesty",
            Q11: "Kindness",
            Q12: "Sociability"
        },
        options: {
            O1: "Excellent",
            O2: "Very Good",
            O3: "Good",
            O4: "Average",
            O5: "Poor",
            O6: "Very Poor",
            O7: "Not Applicable"
        }
    },
    grade_subjects: {
        title: "Subject Knowledge - Based on previous exam or the teacher's observation",
        columns: {
            Q1: "Local Language",
            Q2: "English",
            Q3: "Mathematics",
            Q4: "Science",
            Q5: "Social Science"
        },
        options: {
            O1: "Outstanding (O - 80% and above)",
            O2: "Excellent (A - 75% to 79%)",
            O3: "Very Good (B - 70% to 74%)",
            O4: "Good (C - 60% to 69%)",
            O5: "Average (D - 50% to 59%)",
            O6: "Below Average (E - 45% -49%)",
            O7: "Poor (P - 40% to 44% )",
            O8: "Very Poor (F - 39% and Below)",
            O9: "Not Applicable"
        }
    },
    grade_intrests: {
        title: "Interest and involvement in Co-curricular Activities",
        columns: {
            Q1: "Essay Writing",
            Q2: "Public Speaking",
            Q3: "Drawing / Painting",
            Q4: "General Knowledge",
            Q5: "Dance",
            Q6: "Singing / Music",
            Q7: "Sports & Games",
            Q8: "Crafts",
            Q9: "Computer"
        },
        options: {
            O1: "Excellent",
            O2: "Very Good",
            O3: "Good",
            O4: "Average",
            O5: "Poor",
            O6: "Very Poor",
            O7: "Not Applicable"
        }
    },
    grade_specifics: {
        title: "Specifics",
        columns: {
            Q1: "Is there any specific or extraordinary talent / quality in the child? Please specify.",
            Q2: "Is there any specific or unusual challenge or problem faced by the child? Kindly explain.",
            Q3: "Any specific action plan or suggestion with regard to the child? Please share."
        }
    }
};
/* harmony default export */ const grades = (gradeConstants);

// EXTERNAL MODULE: ./styles/Grade.module.css
var Grade_module = __webpack_require__(6597);
var Grade_module_default = /*#__PURE__*/__webpack_require__.n(Grade_module);
// EXTERNAL MODULE: external "formik"
var external_formik_ = __webpack_require__(2296);
;// CONCATENATED MODULE: ./pages/grade/create/[bg_id]/[exam].js







const CreateGrade = ({ bg , students , exam  })=>{
    const gradeOptions = bg.grade_options;
    const [selected, setSelected] = (0,external_react_.useState)(students[0]);
    const [qualities, setQualities] = (0,external_react_.useState)(true);
    const [subject, setSubject] = (0,external_react_.useState)(false);
    const [intrests, setIntrests] = (0,external_react_.useState)(false);
    const [specifics, setSpecifics] = (0,external_react_.useState)(false);
    const reset = ()=>{
        formik.resetForm();
        setQualities(true);
        setSubject(false);
        setIntrests(false);
        setSpecifics(false);
    };
    const formik = (0,external_formik_.useFormik)({
        initialValues: {
            grades: {
                grade_qualities: {
                    Q1: "",
                    Q2: "O7",
                    Q3: "O7",
                    Q4: "O7",
                    Q5: "O7",
                    Q6: "O7",
                    Q7: "O7",
                    Q8: "O7",
                    Q9: "O7",
                    Q10: "O7",
                    Q11: "O7",
                    Q12: "O7"
                },
                grade_subjects: {
                    Q1: "O9",
                    Q2: "O9",
                    Q3: "O9",
                    Q4: "O9",
                    Q5: "O9"
                },
                grade_intrests: {
                    Q1: "O7",
                    Q2: "O7",
                    Q3: "O7",
                    Q4: "O7",
                    Q5: "O7",
                    Q6: "O7",
                    Q7: "O7",
                    Q8: "O7",
                    Q9: "O7"
                },
                grade_specifics: {
                    Q1: "",
                    Q2: "",
                    Q3: ""
                }
            }
        },
        validate: (values)=>{
            const errors = {};
            const grade_qualities = {}, grade_subjects = {}, grade_intrests = {}, grade_specifics = {};
            for (const [key, value] of Object.entries(values.grades.grade_qualities)){
                if (value === "") grade_qualities[key] = "Required";
            }
            for (const [key1, value1] of Object.entries(values.grades.grade_subjects)){
                if (value1 === "") grade_subjects[key1] = "Required";
            }
            for (const [key2, value2] of Object.entries(values.grades.grade_intrests)){
                if (value2 === "") grade_intrests[key2] = "Required";
            }
            if (values.grades.grade_specifics.Q1 === "") {
                grade_specifics.Q1 = "Required";
            }
            if (values.grades.grade_specifics.Q2 === "") {
                grade_specifics.Q2 = "Required";
            }
            if (values.grades.grade_specifics.Q3 === "") {
                grade_specifics.Q3 = "Required";
            }
            const grades = {};
            if (Object.keys(grade_qualities).length > 0) grades.grade_qualities = grade_qualities;
            if (Object.keys(grade_subjects).length > 0) grades.grade_subjects = grade_subjects;
            if (Object.keys(grade_intrests).length > 0) grades.grade_intrests = grade_intrests;
            if (Object.keys(grade_specifics).length > 0) grades.grade_specifics = grade_specifics;
            if (Object.keys(grades).length > 0) errors.grades = grades;
            return errors;
        },
        onSubmit: async (values)=>{
            let grade_qualities = [];
            let grade_subjects = [];
            let grade_intrests = [];
            let grade_specifics = [];
            for (let [key, value] of Object.entries(values.grades.grade_qualities)){
                console.log(key, value);
                grade_qualities.push(value);
            }
            for (let [key1, value1] of Object.entries(values.grades.grade_subjects)){
                grade_subjects.push(value1);
            }
            for (let [key2, value2] of Object.entries(values.grades.grade_intrests)){
                grade_intrests.push(value2);
            }
            for (let [key3, value3] of Object.entries(values.grades.grade_specifics)){
                grade_specifics.push(value3);
            }
            console.log("res");
            let res = await fetch(`${baseUrl/* default */.Z}/api/student/grade/insert`, {
                method: "POST",
                headers: {
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    student_id: selected.student_id,
                    bg_id: selected.bg_id,
                    exam: exam,
                    grade: selected.grade,
                    grade_qualities,
                    grade_subjects,
                    grade_intrests,
                    grade_specifics
                })
            });
            console.log(res);
            let data = await res.json();
            console.log(data);
            if (data.error != null) {
                alert(data.message);
            } else {
                alert("Submitted");
                reset();
            }
        }
    });
    function changeTab(e, tab) {
        e.preventDefault();
        setQualities(tab == "qualities");
        setSubject(tab == "subjects");
        setIntrests(tab == "intrests");
        setSpecifics(tab == "specifics");
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_formik_.FormikProvider, {
        value: formik,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "bg-blue-600 flex justify-center text-center h-60",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("span", {
                    className: "m-auto text-5xl text-white font-extrabold",
                    children: [
                        "Evaluation for ",
                        exam
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex flex-row justify-content-center m-5 w-auto",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col p-20 shadow-xl shadow-slate-100 hover:shadow-slate-700 rounded-xl",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "font-extrabold text-blue-600 text-center justify-center",
                                children: "Student"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: !selected ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                                className: "text-blue-700",
                                                children: [
                                                    selected.f_name,
                                                    " ",
                                                    selected.m_name,
                                                    " ",
                                                    selected.l_name
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                        className: "text-blue-600 text-2xl",
                                                        children: selected.grade
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                        className: "text-blue-600 text-2xl",
                                                        children: selected.dob
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                                        className: "text-blue-600 text-2xl",
                                                        children: selected.gender
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("form", {
                        onSubmit: formik.handleSubmit,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex flex-col p-20 pt-10 shadow-xl shadow-slate-100 hover:shadow-slate-700 rounded-xl w-auto",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "font-extrabold text-blue-600 text-center justify-center",
                                    children: "Sections"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "flex flex-row ",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: qualities ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "qualities");
                                            },
                                            children: "Qualities"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: subject ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "subjects");
                                            },
                                            children: "Academics"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: intrests ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "intrests");
                                            },
                                            children: "Intrests"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: specifics ? "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm  bg-blue-600 text-white " : "flex flex-col border m-1 p-2 font-semibold rounded-xl text-sm",
                                            onClick: (e)=>{
                                                changeTab(e, "specifics");
                                            },
                                            children: "Specifics"
                                        })
                                    ]
                                }),
                                (()=>{
                                    if (!qualities) return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
                                    else {
                                        let obj = "grade_qualities";
                                        let gradeOptions = grades[obj];
                                        let columns = gradeOptions.columns;
                                        let grade_opt = gradeOptions.options;
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                Object.keys(columns).map((key_col)=>{
                                                    let value = columns[key_col];
                                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                className: "text-blue-600 font-bold text-lg",
                                                                children: value
                                                            }),
                                                            formik.errors.grades?.[obj]?.[key_col] && formik.touched.grades?.[obj]?.[key_col] ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-red-500",
                                                                children: formik.errors.grades[obj][key_col]
                                                            }) : null,
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "border-2 hover:border-blue-600 p-1",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: (Grade_module_default()).radio_toolbar,
                                                                    children: Object.keys(grade_opt).map((key_opt)=>{
                                                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Field, {
                                                                                    type: "radio",
                                                                                    id: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    name: `grades.${obj}.${key_col}`,
                                                                                    value: key_opt
                                                                                }, `${obj}.${key_opt}`),
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    htmlFor: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    children: [
                                                                                        grade_opt[key_opt],
                                                                                        " "
                                                                                    ]
                                                                                }, `${obj}.${key_opt}l`)
                                                                            ]
                                                                        });
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }, key_col);
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "border-2 mt-5 border-blue-200 w-full hover:bg-gradient-to-r from-blue-500 to-indigo-500 rounded-md py-3 hover:text-gray-50 text-lg",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setQualities(false);
                                                        setSubject(true);
                                                    },
                                                    children: "Next"
                                                })
                                            ]
                                        });
                                    }
                                })(),
                                (()=>{
                                    if (!subject) return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
                                    else {
                                        let obj = "grade_subjects";
                                        let gradeOptions = grades[obj];
                                        let columns = gradeOptions.columns;
                                        let grade_opt = gradeOptions.options;
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                                            children: "Grades for Subjects "
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                            children: Object.keys(grade_opt).map((key_opt)=>{
                                                                return /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                                                                    children: grade_opt[key_opt]
                                                                }, grade_opt[key_opt]);
                                                            })
                                                        })
                                                    ]
                                                }),
                                                Object.keys(columns).map((key_col)=>{
                                                    let value = columns[key_col];
                                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                className: "text-blue-600 font-bold text-lg",
                                                                children: value
                                                            }),
                                                            formik.errors.grades?.[obj]?.[key_col] && formik.touched.grades?.[obj]?.[key_col] ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-red-500",
                                                                children: formik.errors.grades[obj][key_col]
                                                            }) : null,
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "border-2 hover:border-blue-600 p-1",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: (Grade_module_default()).radio_toolbar,
                                                                    children: Object.keys(grade_opt).map((key_opt)=>{
                                                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Field, {
                                                                                    type: "radio",
                                                                                    id: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    name: `grades.${obj}.${key_col}`,
                                                                                    value: key_opt
                                                                                }, `${obj}.${key_opt}`),
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    htmlFor: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    children: [
                                                                                        grade_opt[key_opt].split(" (")[0],
                                                                                        " "
                                                                                    ]
                                                                                }, `${obj}.${key_opt}l`)
                                                                            ]
                                                                        });
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }, key_col);
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "border-2 mt-5 border-blue-200 w-full hover:bg-gradient-to-r from-blue-500 to-indigo-500 rounded-md py-3 hover:text-gray-50 text-lg",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setSubject(false);
                                                        setIntrests(true);
                                                    },
                                                    children: "Next"
                                                })
                                            ]
                                        });
                                    }
                                })(),
                                (()=>{
                                    if (!intrests) return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
                                    else {
                                        let obj = "grade_intrests";
                                        let gradeOptions = grades[obj];
                                        let columns = gradeOptions.columns;
                                        let grade_opt = gradeOptions.options;
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                Object.keys(columns).map((key_col)=>{
                                                    let value = columns[key_col];
                                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                                                                className: "text-blue-600 font-bold text-lg",
                                                                children: value
                                                            }),
                                                            formik.errors.grades?.[obj]?.[key_col] && formik.touched.grades?.[obj]?.[key_col] ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text-red-500",
                                                                children: formik.errors.grades[obj][key_col]
                                                            }) : null,
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "border-2 hover:border-blue-600 p-1",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                    className: (Grade_module_default()).radio_toolbar,
                                                                    children: Object.keys(grade_opt).map((key_opt)=>{
                                                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime_.jsx(external_formik_.Field, {
                                                                                    type: "radio",
                                                                                    id: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    name: `grades.${obj}.${key_col}`,
                                                                                    value: key_opt
                                                                                }, `${obj}.${key_opt}`),
                                                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("label", {
                                                                                    htmlFor: `grades.${obj}.${key_col}.${key_opt}`,
                                                                                    children: [
                                                                                        grade_opt[key_opt],
                                                                                        " "
                                                                                    ]
                                                                                }, `${obj}.${key_opt}l`)
                                                                            ]
                                                                        });
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    }, key_col);
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                                    className: "border-2 mt-5 border-blue-200 w-full hover:bg-gradient-to-r from-blue-500 to-indigo-500 rounded-md py-3 hover:text-gray-50 text-lg",
                                                    onClick: (e)=>{
                                                        e.preventDefault();
                                                        setIntrests(false);
                                                        setSpecifics(true);
                                                    },
                                                    children: "Next"
                                                })
                                            ]
                                        });
                                    }
                                })(),
                                !specifics ? /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {}) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            className: "text-blue-600 font-bold text-lg pt-4",
                                            htmlFor: "Q1",
                                            children: "Is there any specific or extraordinary talent / quality in the child? Please specify. "
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            className: "bg-white focus:shadow-outline border border-gray-300 rounded-lg py-2 px-4 block w-full appearance-none leading-normal",
                                            type: "textarea",
                                            ...formik.getFieldProps("grades.grade_specifics.Q1")
                                        }),
                                        formik.errors?.grades?.grade_specifics?.Q1 && formik.touched?.grades?.grade_specifics?.Q1 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-red-500",
                                            children: formik.errors.grades.grade_specifics.Q1
                                        }) : null,
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            className: "text-blue-600 font-bold text-lg pt-4",
                                            htmlFor: "grade",
                                            children: "Is there any specific or unusual challenge or problem faced by the child? Kindly explain."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            className: "bg-white focus:shadow-outline border border-gray-300 rounded-lg py-2 px-4 block w-full appearance-none leading-normal",
                                            type: "textarea",
                                            ...formik.getFieldProps("grades.grade_specifics.Q2")
                                        }),
                                        formik.errors?.grades?.grade_specifics?.Q2 && formik.touched?.grades?.grade_specifics?.Q2 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-red-500",
                                            children: formik.errors.grades.grade_specifics.Q2
                                        }) : null,
                                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                                            className: "text-blue-600 font-bold text-lg pt-4",
                                            htmlFor: "grade",
                                            children: "Any specific action plan or suggestion with regard to the child? Please share."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                            className: "bg-white focus:shadow-outline border border-gray-300 rounded-lg py-2 px-4 block w-full appearance-none leading-normal",
                                            type: "textarea",
                                            ...formik.getFieldProps("grades.grade_specifics.Q3")
                                        }),
                                        formik.errors?.grades?.grade_specifics?.Q3 && formik.touched?.grades?.grade_specifics?.Q3 ? /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "text-red-500",
                                            children: formik.errors.grades.grade_specifics.Q3
                                        }) : null,
                                        /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                            className: "border-2 border-blue-200 w-full hover:bg-emerald-600 rounded-md py-3 hover:text-gray-50 text-lg",
                                            type: "submit",
                                            onClick: formik.handleSubmit,
                                            children: "Submit"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "flex flex-col p-10 w-3/12 shadow-xl shadow-slate-100 hover:shadow-slate-700 rounded-xl",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "font-extrabold text-blue-600 text-center justify-center",
                                children: "All students"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "overflow-y-auto h-30",
                                children: students?.map((student)=>{
                                    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        className: "p-2 mb-2 bg-yellow-100 hover:bg-yellow-200 rounded-xl w-11/12 ",
                                        onClick: (e)=>{
                                            e.preventDefault();
                                            setSelected(student);
                                            reset();
                                        },
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                            className: "text-blue-700 font-semibold text-center",
                                            children: [
                                                " ",
                                                student.f_name,
                                                " ",
                                                student.m_name,
                                                " ",
                                                student.l_name
                                            ]
                                        })
                                    }, student.student_id);
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
async function getServerSideProps({ params: { bg_id , exam  }  }) {
    const bg_data = await fetch(`${baseUrl/* default */.Z}/api/balgurukul/${bg_id}`);
    const stdnt = await fetch(`${baseUrl/* default */.Z}/api/student/bg/${bg_id}`);
    const bg = await bg_data.json();
    const stdn = await stdnt.json();
    if (stdn.length == 0) {
        return {
            redirect: {
                permanent: false,
                destination: "/balgurukul/" + bg_id
            },
            props: {}
        };
    }
    return {
        props: {
            bg,
            students: stdn,
            exam
        }
    };
}
/* harmony default export */ const _exam_ = (CreateGrade);


/***/ }),

/***/ 2296:
/***/ ((module) => {

"use strict";
module.exports = require("formik");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5214));
module.exports = __webpack_exports__;

})();